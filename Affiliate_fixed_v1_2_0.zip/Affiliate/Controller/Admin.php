<?php

/**
 * Affiliate module for FOSSBilling - admin routes and navigation.
 * Licensed under the Apache License, Version 2.0
 */

namespace Box\Mod\Affiliate\Controller;

use FOSSBilling\InjectionAwareInterface;

class Admin implements InjectionAwareInterface
{
    protected ?\Pimple\Container $di = null;

    public function setDi(\Pimple\Container $di): void
    {
        $this->di = $di;
    }

    public function getDi(): ?\Pimple\Container
    {
        return $this->di;
    }

    public function fetchNavigation(): array
    {
        $link = fn (string $path) => $this->di['url']->adminLink($path);

        return [
            'group' => [
                'index' => 1550,
                'location' => 'affiliate',
                'label' => __trans('Affiliates'),
                'class' => 'affiliate',
            ],
            'subpages' => [
                ['location' => 'affiliate', 'label' => __trans('Overview'), 'index' => 100, 'uri' => $link('affiliate'), 'class' => ''],
                ['location' => 'affiliate', 'label' => __trans('Affiliates'), 'index' => 200, 'uri' => $link('affiliate/affiliates'), 'class' => ''],
                ['location' => 'affiliate', 'label' => __trans('Referrals'), 'index' => 300, 'uri' => $link('affiliate/referrals'), 'class' => ''],
                ['location' => 'affiliate', 'label' => __trans('Commissions'), 'index' => 400, 'uri' => $link('affiliate/commissions'), 'class' => ''],
                ['location' => 'affiliate', 'label' => __trans('Payouts'), 'index' => 500, 'uri' => $link('affiliate/payouts'), 'class' => ''],
                ['location' => 'affiliate', 'label' => __trans('Settings'), 'index' => 600, 'uri' => $link('affiliate/settings'), 'class' => ''],
            ],
        ];
    }

    public function register(\Box_App &$app): void
    {
        $app->get('/affiliate', 'get_index', [], static::class);
        $app->get('/affiliate/affiliates', 'get_affiliates', [], static::class);
        // Query-string form is the canonical one (/affiliate/manage?id=5); the path form is kept for old links.
        $app->get('/affiliate/manage', 'get_manage', [], static::class);
        $app->get('/affiliate/manage/:id', 'get_manage', ['id' => '[0-9]+'], static::class);
        $app->get('/affiliate/manage/:id/', 'get_manage', ['id' => '[0-9]+'], static::class);
        $app->get('/affiliate/referrals', 'get_referrals', [], static::class);
        $app->get('/affiliate/commissions', 'get_commissions', [], static::class);
        $app->get('/affiliate/payouts', 'get_payouts', [], static::class);
        $app->get('/affiliate/settings', 'get_settings', [], static::class);
    }

    public function get_index(\Box_App $app)
    {
        $this->di['is_admin_logged'];

        return $app->render('mod_affiliate_index');
    }

    public function get_affiliates(\Box_App $app)
    {
        $this->di['is_admin_logged'];

        return $app->render('mod_affiliate_affiliates');
    }

    public function get_manage(\Box_App $app, $id = null)
    {
        $this->di['is_admin_logged'];

        $id = (int) ($id ?: ($_GET['id'] ?? 0));
        if ($id <= 0) {
            // Router did not pass the id: read it from the path (/affiliate/manage/5).
            $path = (string) parse_url((string) ($_SERVER['REQUEST_URI'] ?? ''), PHP_URL_PATH);
            if (preg_match('#/affiliate/manage/(\d+)/?$#', $path, $m)) {
                $id = (int) $m[1];
            }
        }
        if ($id <= 0) {
            // No affiliate selected: send the admin to the list instead of a 404.
            header('Location: ' . $this->di['url']->adminLink('affiliate/affiliates'), true, 302);
            exit;
        }

        return $app->render('mod_affiliate_manage', ['affiliate_id' => $id]);
    }

    public function get_referrals(\Box_App $app)
    {
        $this->di['is_admin_logged'];

        return $app->render('mod_affiliate_referrals');
    }

    public function get_commissions(\Box_App $app)
    {
        $this->di['is_admin_logged'];

        return $app->render('mod_affiliate_commissions');
    }

    public function get_payouts(\Box_App $app)
    {
        $this->di['is_admin_logged'];

        return $app->render('mod_affiliate_payouts');
    }

    public function get_settings(\Box_App $app)
    {
        $this->di['is_admin_logged'];

        return $app->render('mod_affiliate_settings');
    }
}
