<?php

/**
 * Affiliate module for FOSSBilling - client area routes and referral link handler.
 * Licensed under the Apache License, Version 2.0
 */

namespace Box\Mod\Affiliate\Controller;

use Box\Mod\Affiliate\Service;
use FOSSBilling\InjectionAwareInterface;

class Client implements InjectionAwareInterface
{
    protected ?\Pimple\Container $di = null;

    public function setDi(\Pimple\Container $di): void
    {
        $this->di = $di;
    }

    public function getDi(): ?\Pimple\Container
    {
        return $this->di;
    }

    public function register(\Box_App &$app): void
    {
        $app->get('/affiliate', 'get_index', [], static::class);
        // Public referral link: https://example.com/a/CODE[?to=/order]
        // The code is validated inside the handler, so the route accepts any single path segment.
        // Conditions use a plain character class (no negated class) so every router version accepts them.
        $app->get('/a/:code', 'get_track', ['code' => '[A-Za-z0-9_-]+'], static::class);
        $app->get('/ref/:code', 'get_track', ['code' => '[A-Za-z0-9_-]+'], static::class);
        // Fallback links that use no path parameter at all: /affiliate/go?c=CODE and /affiliate/go/CODE
        $app->get('/affiliate/go', 'get_track', [], static::class);
        $app->get('/affiliate/ref/:code', 'get_track', ['code' => '[A-Za-z0-9_-]+'], static::class);
        $app->get('/affiliate/go/:code', 'get_track', ['code' => '[A-Za-z0-9_-]+'], static::class);
    }

    public function get_index(\Box_App $app)
    {
        // Primary referral link: /affiliate?ref=CODE[&to=/order]. This rides on the dashboard route,
        // which the router always resolves, so it cannot 404 like path-parameter routes can.
        $ref = (string) ($_GET['ref'] ?? $_GET['c'] ?? '');
        if ($ref !== '') {
            return $this->get_track($app, $ref);
        }

        $this->di['is_client_logged'];

        return $app->render('mod_affiliate_index');
    }

    public function get_track(\Box_App $app, $code = null)
    {
        $code = (string) ($code ?: ($_GET['c'] ?? $_GET['code'] ?? $_GET['ref'] ?? ''));
        if ($code === '') {
            // Last resort: read the code straight from the request path (/a/CODE, /ref/CODE, /affiliate/go/CODE).
            $path = (string) parse_url((string) ($_SERVER['REQUEST_URI'] ?? ''), PHP_URL_PATH);
            if (preg_match('#/(?:a|ref|affiliate/ref|affiliate/go)/([A-Za-z0-9_-]{3,32})/?$#', $path, $m)) {
                $code = $m[1];
            }
        }
        /** @var Service $service */
        $service = $this->di['mod_service']('affiliate');
        $to = $service->sanitizeLandingPath($_GET['to'] ?? null);

        try {
            $result = $service->trackVisit((string) $code, $to);
        } catch (\Throwable $e) {
            // Never break the visitor's journey because of a tracking problem.
            error_log('Affiliate trackVisit: ' . $e->getMessage());
            $result = null;
        }

        if ($result !== null) {
            $settings = $service->getSettings();
            $existing = $service->getAffiliateByCode((string) ($_COOKIE[Service::COOKIE_NAME] ?? ''));
            $keep = $settings['attribution'] === 'first' && $existing && $existing['status'] === 'active';
            $secure = $service->isHttps();
            $cookie = static fn (int $ttl) => [
                'expires' => time() + $ttl,
                'path' => '/',
                'secure' => $secure,
                'httponly' => true,
                'samesite' => 'Lax',
            ];
            if (!$keep) {
                setcookie(Service::COOKIE_NAME, (string) $result['affiliate']['code'], $cookie(max(1, (int) $settings['cookie_days']) * 86400));
            }
            // Anonymous visitor id: makes "unique clicks" accurate even behind a shared IP / proxy / CDN.
            setcookie(Service::VISITOR_COOKIE, (string) $result['visitor_id'], $cookie(365 * 86400));
        }

        // Never bounce back into the tracking endpoint (redirect loop).
        if (preg_match('#^/(?:a|ref)/|^/affiliate/go#', $to) || ($to === '/affiliate' && isset($_GET['ref']))) {
            $to = '/';
        }

        // $base is guaranteed absolute (scheme + host); $to always starts with "/".
        if ($to === '' || $to[0] !== '/') {
            $to = '/' . ltrim($to, '/');
        }
        $base = $service->getSystemUrl();

        // The redirect must never be cached by a browser, proxy or CDN, otherwise repeat clicks would not reach the server.
        header('Cache-Control: no-store, no-cache, must-revalidate, private');
        header('Pragma: no-cache');
        header('Expires: 0');
        header('Location: ' . $base . $to, true, 302);
        exit;
    }
}
