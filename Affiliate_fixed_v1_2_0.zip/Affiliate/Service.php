<?php

/**
 * Affiliate module for FOSSBilling.
 *
 * Licensed under the Apache License, Version 2.0
 */

namespace Box\Mod\Affiliate;

use FOSSBilling\InformationException;
use FOSSBilling\InjectionAwareInterface;

class Service implements InjectionAwareInterface
{
    public const COOKIE_NAME = 'fb_affiliate';
    public const VISITOR_COOKIE = 'fb_aff_vid';
    /** Same visitor hitting the same link again within this many seconds = refresh / double click, not a new click. */
    public const CLICK_DEDUPE_SECONDS = 30;
    /** Cookie-less signup matching: a click from the same IP this long before signup is attributed. */
    public const IP_MATCH_SECONDS = 86400;

    public const AFFILIATE_STATUSES = ['pending', 'active', 'suspended', 'rejected'];
    public const PAYOUT_METHODS = ['paypal', 'bank', 'credit', 'crypto', 'other'];

    protected ?\Pimple\Container $di = null;
    private ?array $settingsCache = null;

    public function setDi(\Pimple\Container $di): void
    {
        $this->di = $di;
        $this->autoUpgradeSchema();
    }

    public function getDi(): ?\Pimple\Container
    {
        return $this->di;
    }

    /* ---------------------------------------------------------------------
     * Install / uninstall / permissions
     * ------------------------------------------------------------------ */

    public const SCHEMA_VERSION = '1.2.0';

    /**
     * Table definitions (column + key lines). Single source of truth used both to create
     * missing tables and to add columns/keys missing from tables created by older versions.
     */
    private function tableDefinitions(): array
    {
        return [
            'affiliate_account' => <<<'SQL'
            id BIGINT(20) NOT NULL AUTO_INCREMENT,
            client_id BIGINT(20) NOT NULL,
            code VARCHAR(32) NOT NULL,
            status VARCHAR(20) NOT NULL DEFAULT 'pending',
            commission_type VARCHAR(10) NULL DEFAULT NULL,
            commission_value DECIMAL(13,2) NULL DEFAULT NULL,
            payout_method VARCHAR(20) NULL DEFAULT NULL,
            payout_details TEXT NULL,
            notes TEXT NULL,
            terms_accepted_at DATETIME NULL DEFAULT NULL,
            approved_at DATETIME NULL DEFAULT NULL,
            created_at DATETIME NULL DEFAULT NULL,
            updated_at DATETIME NULL DEFAULT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY uq_affiliate_client (client_id),
            UNIQUE KEY uq_affiliate_code (code),
            KEY idx_affiliate_status (status)
        
SQL,
            'affiliate_visit' => <<<'SQL'
            id BIGINT(20) NOT NULL AUTO_INCREMENT,
            affiliate_id BIGINT(20) NOT NULL,
            ip_hash CHAR(64) NULL DEFAULT NULL,
            user_agent VARCHAR(255) NULL DEFAULT NULL,
            referer VARCHAR(255) NULL DEFAULT NULL,
            landing VARCHAR(255) NULL DEFAULT NULL,
            visitor_id CHAR(32) NULL DEFAULT NULL,
            is_unique TINYINT(1) NOT NULL DEFAULT 0,
            created_at DATETIME NULL DEFAULT NULL,
            PRIMARY KEY (id),
            KEY idx_visit_affiliate (affiliate_id, created_at),
            KEY idx_visit_visitor (affiliate_id, visitor_id),
            KEY idx_visit_ip (ip_hash, created_at)
        
SQL,
            'affiliate_referral' => <<<'SQL'
            id BIGINT(20) NOT NULL AUTO_INCREMENT,
            affiliate_id BIGINT(20) NOT NULL,
            client_id BIGINT(20) NOT NULL,
            source VARCHAR(20) NOT NULL DEFAULT 'cookie',
            visit_id BIGINT(20) NULL DEFAULT NULL,
            created_at DATETIME NULL DEFAULT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY uq_referral_client (client_id),
            KEY idx_referral_affiliate (affiliate_id)
        
SQL,
            'affiliate_commission' => <<<'SQL'
            id BIGINT(20) NOT NULL AUTO_INCREMENT,
            affiliate_id BIGINT(20) NOT NULL,
            referral_id BIGINT(20) NULL DEFAULT NULL,
            client_id BIGINT(20) NULL DEFAULT NULL,
            invoice_id BIGINT(20) NULL DEFAULT NULL,
            payout_id BIGINT(20) NULL DEFAULT NULL,
            type VARCHAR(20) NOT NULL DEFAULT 'commission',
            status VARCHAR(20) NOT NULL DEFAULT 'pending',
            base_amount DECIMAL(13,2) NOT NULL DEFAULT 0,
            rate_type VARCHAR(10) NULL DEFAULT NULL,
            rate_value DECIMAL(13,2) NULL DEFAULT NULL,
            amount DECIMAL(13,2) NOT NULL DEFAULT 0,
            description VARCHAR(255) NULL DEFAULT NULL,
            available_at DATETIME NULL DEFAULT NULL,
            created_at DATETIME NULL DEFAULT NULL,
            updated_at DATETIME NULL DEFAULT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY uq_commission_invoice_type (invoice_id, type),
            KEY idx_commission_affiliate (affiliate_id, status),
            KEY idx_commission_payout (payout_id),
            KEY idx_commission_status (status, available_at)
        
SQL,
            'affiliate_invoice' => <<<'SQL'
            id BIGINT(20) NOT NULL AUTO_INCREMENT,
            invoice_id BIGINT(20) NOT NULL,
            affiliate_id BIGINT(20) NOT NULL,
            referral_id BIGINT(20) NULL DEFAULT NULL,
            client_id BIGINT(20) NOT NULL DEFAULT 0,
            status VARCHAR(20) NOT NULL DEFAULT 'counted',
            base_amount DECIMAL(13,2) NOT NULL DEFAULT 0,
            commission_amount DECIMAL(13,2) NOT NULL DEFAULT 0,
            paid_at DATETIME NULL DEFAULT NULL,
            created_at DATETIME NULL DEFAULT NULL,
            updated_at DATETIME NULL DEFAULT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY uq_affinvoice_invoice (invoice_id),
            KEY idx_affinvoice_affiliate (affiliate_id, status),
            KEY idx_affinvoice_referral (referral_id)
        
SQL,
            'affiliate_payout' => <<<'SQL'
            id BIGINT(20) NOT NULL AUTO_INCREMENT,
            affiliate_id BIGINT(20) NOT NULL,
            amount DECIMAL(13,2) NOT NULL DEFAULT 0,
            method VARCHAR(20) NULL DEFAULT NULL,
            details TEXT NULL,
            status VARCHAR(20) NOT NULL DEFAULT 'pending',
            transaction_ref VARCHAR(255) NULL DEFAULT NULL,
            admin_note TEXT NULL,
            processed_at DATETIME NULL DEFAULT NULL,
            created_at DATETIME NULL DEFAULT NULL,
            updated_at DATETIME NULL DEFAULT NULL,
            PRIMARY KEY (id),
            KEY idx_payout_affiliate (affiliate_id),
            KEY idx_payout_status (status)
        
SQL,
            'affiliate_product_rate' => <<<'SQL'
            id BIGINT(20) NOT NULL AUTO_INCREMENT,
            product_id BIGINT(20) NOT NULL,
            rate_type VARCHAR(10) NOT NULL DEFAULT 'percent',
            rate_value DECIMAL(13,2) NOT NULL DEFAULT 0,
            created_at DATETIME NULL DEFAULT NULL,
            updated_at DATETIME NULL DEFAULT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY uq_product_rate (product_id)
        
SQL,
            'affiliate_setting' => <<<'SQL'
            setting_key VARCHAR(64) NOT NULL,
            setting_value TEXT NULL,
            PRIMARY KEY (setting_key)
        
SQL,
        ];
    }

    /**
     * Creates missing tables and upgrades tables from older module versions
     * (adds missing columns and keys). Safe to run repeatedly.
     */
    public function ensureSchema(): void
    {
        $db = $this->di['db'];
        $opts = 'ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci';

        foreach ($this->tableDefinitions() as $table => $body) {
            $db->exec("CREATE TABLE IF NOT EXISTS $table (\n$body\n) $opts");

            $existing = [];
            foreach ($db->getAll("SHOW COLUMNS FROM $table") as $col) {
                $existing[strtolower((string) ($col['Field'] ?? $col['field'] ?? ''))] = true;
            }
            $indexes = [];
            foreach ($db->getAll("SHOW INDEX FROM $table") as $idx) {
                $indexes[strtolower((string) ($idx['Key_name'] ?? $idx['key_name'] ?? ''))] = true;
            }

            $prev = null;
            foreach (preg_split('/\r?\n/', $body) as $line) {
                $line = trim(rtrim(trim($line), ','));
                if ($line === '') {
                    continue;
                }
                if (preg_match('/^(PRIMARY KEY|UNIQUE KEY|KEY)\s+(\w+)?\s*\(/i', $line, $m)) {
                    $keyName = strtolower($m[1]) === 'primary key' ? 'primary' : strtolower((string) $m[2]);
                    if (!isset($indexes[$keyName])) {
                        try {
                            $db->exec("ALTER TABLE $table ADD $line");
                        } catch (\Throwable $e) {
                            error_log("Affiliate: could not add key $keyName on $table: " . $e->getMessage());
                        }
                    }
                    continue;
                }
                if (!preg_match('/^(\w+)\s+/', $line, $m)) {
                    continue;
                }
                $name = $m[1];
                if (!isset($existing[strtolower($name)])) {
                    $after = $prev !== null ? " AFTER $prev" : ' FIRST';
                    try {
                        $db->exec("ALTER TABLE $table ADD COLUMN $line$after");
                    } catch (\Throwable $e) {
                        // Retry without positioning clause
                        $db->exec("ALTER TABLE $table ADD COLUMN $line");
                    }
                }
                $prev = $name;
            }
        }

        // Purchase ledger: one row per paid invoice of a referred client (even when the commission is 0).
        // Seed it from commissions created by older versions so existing numbers stay consistent.
        try {
            $db->exec(
                "INSERT IGNORE INTO affiliate_invoice
                    (invoice_id, affiliate_id, referral_id, client_id, status, base_amount, commission_amount, paid_at, created_at, updated_at)
                 SELECT m.invoice_id, m.affiliate_id, m.referral_id, COALESCE(m.client_id, 0),
                        CASE WHEN m.status = 'reversed' THEN 'refunded' ELSE 'counted' END,
                        m.base_amount, m.amount, m.created_at, m.created_at, m.updated_at
                 FROM affiliate_commission m WHERE m.type = 'commission' AND m.invoice_id IS NOT NULL"
            );
        } catch (\Throwable $e) {
            error_log('Affiliate: could not backfill purchase ledger: ' . $e->getMessage());
        }
    }

    /** Runs ensureSchema() once per version (cheap marker lookup on every other request). */
    private function autoUpgradeSchema(): void
    {
        static $checked = false;
        if ($checked) {
            return;
        }
        $checked = true;

        try {
            $db = $this->di['db'];
            $current = null;
            try {
                $current = $db->getCell('SELECT setting_value FROM affiliate_setting WHERE setting_key = ?', ['_schema_version']);
            } catch (\Throwable $e) {
                $current = null; // table may not exist yet
            }
            if ($current === self::SCHEMA_VERSION) {
                return;
            }
            $this->ensureSchema();
            $db->exec('REPLACE INTO affiliate_setting (setting_key, setting_value) VALUES (?, ?)', ['_schema_version', self::SCHEMA_VERSION]);
        } catch (\Throwable $e) {
            error_log('Affiliate: schema upgrade failed: ' . $e->getMessage());
        }
    }

    /** Called by FOSSBilling when the extension is updated. */
    public function update(array $manifest): bool
    {
        $this->ensureSchema();
        $this->di['db']->exec('REPLACE INTO affiliate_setting (setting_key, setting_value) VALUES (?, ?)', ['_schema_version', self::SCHEMA_VERSION]);
        $this->connectHooks();

        return true;
    }

    /**
     * Registers the on* event handlers with FOSSBilling right away instead of waiting for the first cron run.
     * Best effort: tracking still works without it because of the self-healing sync() safety net.
     */
    public function connectHooks(): bool
    {
        try {
            $this->di['mod_service']('hook')->batchConnect('affiliate');

            return true;
        } catch (\Throwable $e) {
            error_log('Affiliate: could not register hooks: ' . $e->getMessage());

            return false;
        }
    }

    public function install(): bool
    {
        $this->ensureSchema();
        $this->di['db']->exec('REPLACE INTO affiliate_setting (setting_key, setting_value) VALUES (?, ?)', ['_schema_version', self::SCHEMA_VERSION]);
        $this->connectHooks();

        // Register the e-mail templates shipped in templates/email/ (legacy html_email/ removed - 0.8+ only) (best effort).
        try {
            $this->di['mod_service']('email')->templateBatchGenerate();
        } catch (\Throwable $e) {
            error_log('Affiliate: could not generate e-mail templates: ' . $e->getMessage());
        }

        return true;
    }

    public function uninstall(): bool
    {
        $db = $this->di['db'];
        foreach (['affiliate_setting', 'affiliate_product_rate', 'affiliate_payout', 'affiliate_invoice', 'affiliate_commission', 'affiliate_referral', 'affiliate_visit', 'affiliate_account'] as $table) {
            $db->exec('DROP TABLE IF EXISTS ' . $table);
        }

        return true;
    }

    public function getModulePermissions(): array
    {
        return [
            'can_always_access' => true,
            'manage_payouts' => [
                'type' => 'bool',
                'display_name' => __trans('Manage affiliate payouts'),
                'description' => __trans('Allows the staff member to process, reject and create affiliate payouts and manual commission adjustments.'),
            ],
            'manage_settings' => [
                'type' => 'bool',
                'display_name' => __trans('Manage affiliate settings'),
                'description' => __trans('Allows the staff member to change program settings and product commission rates.'),
            ],
        ];
    }

    /* ---------------------------------------------------------------------
     * Event hooks (discovered by FOSSBilling; cron must run once after install)
     * ------------------------------------------------------------------ */

    public static function onAfterClientSignUp(object $event): void
    {
        try {
            $params = $event->getParameters();
            if (empty($params['id'])) {
                return;
            }
            $event->getDi()['mod_service']('affiliate')->attributeSignup((int) $params['id']);
        } catch (\Throwable $e) {
            error_log('Affiliate onAfterClientSignUp: ' . $e->getMessage());
        }
    }

    public static function onAfterAdminInvoicePaymentReceived(object $event): void
    {
        try {
            $params = $event->getParameters();
            if (empty($params['id'])) {
                return;
            }
            $event->getDi()['mod_service']('affiliate')->processPaidInvoice((int) $params['id']);
        } catch (\Throwable $e) {
            error_log('Affiliate onAfterAdminInvoicePaymentReceived: ' . $e->getMessage());
        }
    }

    public static function onAfterAdminInvoiceRefund(object $event): void
    {
        try {
            $params = $event->getParameters();
            if (empty($params['id'])) {
                return;
            }
            $event->getDi()['mod_service']('affiliate')->reverseInvoiceCommissions((int) $params['id']);
        } catch (\Throwable $e) {
            error_log('Affiliate onAfterAdminInvoiceRefund: ' . $e->getMessage());
        }
    }

    public static function onBeforeAdminCronRun(object $event): void
    {
        try {
            $service = $event->getDi()['mod_service']('affiliate');
            $service->approveDueCommissions();
            // Safety net: attribute missed signups and create commissions for paid invoices the hooks did not see.
            $service->sync(30);
        } catch (\Throwable $e) {
            error_log('Affiliate onBeforeAdminCronRun: ' . $e->getMessage());
        }
    }

    /* ---------------------------------------------------------------------
     * Settings
     * ------------------------------------------------------------------ */

    private function settingsSchema(): array
    {
        return [
            'enabled' => ['bool', 1],
            'registration' => ['enum', 'open', ['open', 'approval', 'closed']],
            'commission_type' => ['enum', 'percent', ['percent', 'fixed']],
            'commission_value' => ['float', 10.0],
            'commission_duration' => ['enum', 'first', ['first', 'months', 'lifetime']],
            'commission_months' => ['int', 12],
            'signup_bonus' => ['float', 0.0],
            'cookie_days' => ['int', 30],
            'attribution' => ['enum', 'last', ['first', 'last']],
            'hold_days' => ['int', 14],
            'approval_mode' => ['enum', 'auto', ['auto', 'manual']],
            'min_payout' => ['float', 50.0],
            'payout_methods' => ['list', ['paypal', 'bank', 'credit'], self::PAYOUT_METHODS],
            'exclude_deposits' => ['bool', 1],
            'block_self_referral' => ['bool', 0],
            'ip_fallback' => ['bool', 1],
            'clawback_on_refund' => ['bool', 1],
            'notify_affiliate' => ['bool', 1],
            'terms_url' => ['string', ''],
            'landing_path' => ['string', '/'],
            'program_description' => ['text', ''],
        ];
    }

    public function getSettings(): array
    {
        if ($this->settingsCache !== null) {
            return $this->settingsCache;
        }

        $out = [];
        foreach ($this->settingsSchema() as $key => $def) {
            $out[$key] = $def[1];
        }

        try {
            $rows = $this->di['db']->getAll('SELECT setting_key, setting_value FROM affiliate_setting');
        } catch (\Throwable $e) {
            $rows = [];
        }
        $schema = $this->settingsSchema();
        foreach ($rows as $row) {
            $key = $row['setting_key'];
            if (!isset($schema[$key])) {
                continue;
            }
            $out[$key] = $this->castSetting($schema[$key], $row['setting_value']);
        }

        return $this->settingsCache = $out;
    }

    private function castSetting(array $def, mixed $value): mixed
    {
        switch ($def[0]) {
            case 'bool':
                return in_array(strtolower((string) $value), ['1', 'true', 'on', 'yes'], true) ? 1 : 0;
            case 'int':
                return max(0, (int) $value);
            case 'float':
                return max(0.0, round((float) $value, 2));
            case 'enum':
                return in_array((string) $value, $def[2], true) ? (string) $value : $def[1];
            case 'list':
                $items = is_array($value) ? $value : json_decode((string) $value, true);
                $items = is_array($items) ? $items : [];

                return array_values(array_intersect($def[2], array_map('strval', $items)));
            default:
                return trim((string) $value);
        }
    }

    public function updateSettings(array $data): bool
    {
        $schema = $this->settingsSchema();
        $db = $this->di['db'];

        foreach ($schema as $key => $def) {
            if (!array_key_exists($key, $data)) {
                continue;
            }
            $value = $this->castSetting($def, $data[$key]);

            if ($key === 'payout_methods' && count($value) === 0) {
                throw new InformationException('At least one payout method must be enabled.');
            }
            if ($key === 'commission_type' || $key === 'commission_value') {
                $type = $data['commission_type'] ?? $this->getSettings()['commission_type'];
                $val = (float) ($data['commission_value'] ?? $this->getSettings()['commission_value']);
                if ($type === 'percent' && $val > 100) {
                    throw new InformationException('Percentage commission cannot exceed 100.');
                }
            }
            if ($key === 'landing_path') {
                $value = $this->sanitizeLandingPath((string) $value, '/');
            }
            if ($key === 'terms_url' && $value !== '' && !preg_match('#^(https?://|/)#i', (string) $value)) {
                throw new InformationException('Terms URL must start with http://, https:// or /.');
            }
            if ($key === 'cookie_days' && $value < 1) {
                $value = 1;
            }

            $stored = is_array($value) ? json_encode($value) : (string) $value;
            $db->exec('REPLACE INTO affiliate_setting (setting_key, setting_value) VALUES (?, ?)', [$key, $stored]);
        }

        $this->settingsCache = null;

        return true;
    }

    /** Safe subset of settings that may be shown to guests/clients. */
    public function getPublicProgram(): array
    {
        $s = $this->getSettings();
        $currency = $this->getDefaultCurrencyCode();

        return [
            'enabled' => (bool) $s['enabled'],
            'registration' => $s['registration'],
            'commission_type' => $s['commission_type'],
            'commission_value' => $s['commission_value'],
            'commission_duration' => $s['commission_duration'],
            'commission_months' => $s['commission_months'],
            'signup_bonus' => $s['signup_bonus'],
            'cookie_days' => $s['cookie_days'],
            'hold_days' => $s['hold_days'],
            'min_payout' => $s['min_payout'],
            'payout_methods' => $s['payout_methods'],
            'terms_url' => $s['terms_url'],
            'program_description' => $s['program_description'],
            'currency' => $currency,
        ];
    }

    /* ---------------------------------------------------------------------
     * Generic helpers
     * ------------------------------------------------------------------ */

    private function now(): string
    {
        return date('Y-m-d H:i:s');
    }

    private function insertRow(string $table, array $row): int
    {
        $cols = array_keys($row);
        $sql = 'INSERT INTO ' . $table . ' (' . implode(',', $cols) . ') VALUES (' . implode(',', array_fill(0, count($cols), '?')) . ')';
        $this->di['db']->exec($sql, array_values($row));

        return (int) $this->di['db']->getCell('SELECT LAST_INSERT_ID()');
    }

    private function updateRow(string $table, int $id, array $row): void
    {
        $sets = [];
        foreach (array_keys($row) as $col) {
            $sets[] = $col . ' = ?';
        }
        $params = array_values($row);
        $params[] = $id;
        $this->di['db']->exec('UPDATE ' . $table . ' SET ' . implode(', ', $sets) . ' WHERE id = ?', $params);
    }

    private function paginate(string $sql, array $params, array $data): array
    {
        $db = $this->di['db'];
        $perPage = max(1, min(200, (int) ($data['per_page'] ?? 20)));
        $page = max(1, (int) ($data['page'] ?? 1));
        $total = (int) $db->getCell("SELECT COUNT(*) FROM ($sql) AS affiliate_count", $params);
        $pages = max(1, (int) ceil($total / $perPage));
        $page = min($page, $pages);
        $list = $db->getAll($sql . ' LIMIT ' . $perPage . ' OFFSET ' . (($page - 1) * $perPage), $params);

        return ['list' => $list, 'total' => $total, 'page' => $page, 'per_page' => $perPage, 'pages' => $pages];
    }

    private function money(mixed $v): float
    {
        return round((float) $v, 2);
    }

    public function getDefaultCurrencyCode(): string
    {
        try {
            return (string) $this->di['mod_service']('currency')->getDefault()->code;
        } catch (\Throwable $e) {
            return 'USD';
        }
    }

    private function rate(string $code): float
    {
        try {
            $r = (float) $this->di['mod_service']('currency')->getRateByCode($code);

            return $r > 0 ? $r : 1.0;
        } catch (\Throwable $e) {
            return 1.0;
        }
    }

    /**
     * Base URL of the installation, always absolute (scheme + host) and without a trailing slash.
     * FOSSBilling removed the $di['config'] service, so read it from the Config class
     * and fall back to older / alternate sources.
     *
     * A configured URL without a scheme (e.g. "panel.example.com") used to be returned as-is, which made
     * "Location: panel.example.com/" a RELATIVE redirect and produced /affiliate -> /panel.example.com (404).
     */
    public function getSystemUrl(): string
    {
        $candidates = [];
        try {
            if (class_exists(\FOSSBilling\Config::class)) {
                $candidates[] = (string) \FOSSBilling\Config::getProperty('url', '');
            }
        } catch (\Throwable $e) {
        }
        if (defined('SYSTEM_URL')) {
            $candidates[] = (string) SYSTEM_URL;
        }
        try {
            $candidates[] = (string) $this->di['url']->link('');
        } catch (\Throwable $e) {
        }

        foreach ($candidates as $url) {
            $url = $this->normalizeBaseUrl($url);
            if ($url !== '') {
                return $url;
            }
        }

        // Last resort: build it from the current request.
        return $this->requestBaseUrl();
    }

    private function requestScheme(): string
    {
        $https = !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off';
        $proto = strtolower((string) ($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? ''));
        if ($https || str_starts_with($proto, 'https')) {
            return 'https';
        }

        return 'http';
    }

    private function requestBaseUrl(): string
    {
        $host = (string) ($_SERVER['HTTP_HOST'] ?? $_SERVER['SERVER_NAME'] ?? 'localhost');
        $host = preg_replace('#[^A-Za-z0-9.\-:\[\]]#', '', $host) ?: 'localhost';

        return $this->requestScheme() . '://' . $host;
    }

    /** Returns a clean absolute base URL, or '' when the value is unusable. */
    private function normalizeBaseUrl(string $url): string
    {
        $url = trim($url);
        if ($url === '') {
            return '';
        }
        if (str_starts_with($url, '//')) {
            $url = $this->requestScheme() . ':' . $url;
        } elseif (!preg_match('#^[a-z][a-z0-9+.\-]*://#i', $url)) {
            if ($url[0] === '/') {
                // Path only (e.g. "/billing"): keep the sub-folder, borrow scheme + host from the request.
                $url = $this->requestBaseUrl() . $url;
            } else {
                // Missing scheme (e.g. "panel.99host.in"): add one.
                $url = $this->requestScheme() . '://' . $url;
            }
        }
        $parts = parse_url($url);
        if (!$parts || empty($parts['host']) || !in_array(strtolower($parts['scheme'] ?? ''), ['http', 'https'], true)) {
            return '';
        }

        return rtrim($url, '/');
    }

    private function getSalt(): string
    {
        try {
            if (class_exists(\FOSSBilling\Config::class)) {
                $salt = \FOSSBilling\Config::getProperty('info.salt', '');
                if (!$salt) {
                    $salt = \FOSSBilling\Config::getProperty('salt', '');
                }

                return (string) $salt;
            }
        } catch (\Throwable $e) {
        }

        return '';
    }

    private function hashIp(string $ip): string
    {
        return hash('sha256', $ip . '|' . $this->getSalt());
    }

    /** Client IP exactly as FOSSBilling records it in client.ip, so clicks and signups can be matched. */
    private function currentIp(): string
    {
        $ip = '';
        try {
            $ip = (string) $this->di['request']->getClientIp();
        } catch (\Throwable $e) {
        }
        if ($ip === '') {
            $ip = (string) ($_SERVER['REMOTE_ADDR'] ?? '');
        }

        return $ip;
    }

    private function ipHash(): string
    {
        return $this->hashIp($this->currentIp());
    }

    public function isHttps(): bool
    {
        return $this->requestScheme() === 'https';
    }

    /**
     * Stable anonymous id of the visitor: the visitor cookie when present, otherwise a deterministic
     * fingerprint (IP + user agent + salt). Used to tell unique visitors apart even behind a proxy/CDN
     * where many visitors share one IP.
     */
    private function resolveVisitorId(): string
    {
        $cookie = (string) ($_COOKIE[self::VISITOR_COOKIE] ?? '');
        if (preg_match('/^[a-f0-9]{32}$/', $cookie)) {
            return $cookie;
        }

        // New browser: a random id (stored in the cookie by the controller). It must NOT be derived from IP + user agent,
        // otherwise all visitors behind one proxy/CDN/NAT with the same browser would share one id and count as one click.
        return bin2hex(random_bytes(16));
    }

    private function hasVisitorCookie(): bool
    {
        return preg_match('/^[a-f0-9]{32}$/', (string) ($_COOKIE[self::VISITOR_COOKIE] ?? '')) === 1;
    }

    /** Bots, link-preview fetchers, HEAD requests and browser prefetches must not count as clicks. */
    private function isNonHumanRequest(): bool
    {
        if (strtoupper((string) ($_SERVER['REQUEST_METHOD'] ?? 'GET')) === 'HEAD') {
            return true;
        }
        $ua = trim((string) ($_SERVER['HTTP_USER_AGENT'] ?? ''));
        if ($ua === '' || preg_match('/bot|crawl|spider|slurp|preview|curl|wget|facebookexternalhit|headlesschrome|python-requests|go-http-client|libwww|scrapy|uptime|lighthouse/i', $ua)) {
            return true;
        }
        foreach (['HTTP_PURPOSE', 'HTTP_SEC_PURPOSE', 'HTTP_X_PURPOSE', 'HTTP_X_MOZ'] as $h) {
            if (isset($_SERVER[$h]) && preg_match('/prefetch|preview/i', (string) $_SERVER[$h])) {
                return true;
            }
        }

        return false;
    }

    private function notify(int $affiliateId, string $template, array $vars = []): void
    {
        if (!$this->getSettings()['notify_affiliate']) {
            return;
        }
        try {
            $clientId = (int) $this->di['db']->getCell('SELECT client_id FROM affiliate_account WHERE id = ?', [$affiliateId]);
            if ($clientId <= 0) {
                return;
            }
            $this->di['mod_service']('email')->sendTemplate(array_merge($vars, [
                'to_client' => $clientId,
                'code' => $template,
            ]));
        } catch (\Throwable $e) {
            error_log('Affiliate notify (' . $template . '): ' . $e->getMessage());
        }
    }

    public function sanitizeLandingPath(?string $path, ?string $fallback = null): string
    {
        $fallback ??= $this->getSettings()['landing_path'] ?? '/';
        $path = trim((string) $path);
        if ($path === '' || $path[0] !== '/' || str_starts_with($path, '//') || str_contains($path, '\\')
            || preg_match('/[\x00-\x1f\x7f]/', $path) || strlen($path) > 200) {
            return $fallback === '' ? '/' : $fallback;
        }

        return $path;
    }

    /* ---------------------------------------------------------------------
     * Affiliates
     * ------------------------------------------------------------------ */

    public function getAffiliate(int $id): ?array
    {
        $row = $this->di['db']->getRow(
            'SELECT a.*, c.first_name, c.last_name, c.email, c.currency AS client_currency
             FROM affiliate_account a LEFT JOIN client c ON c.id = a.client_id WHERE a.id = ?',
            [$id]
        );

        return $row ?: null;
    }

    public function getAffiliateByClient(int $clientId): ?array
    {
        $id = (int) $this->di['db']->getCell('SELECT id FROM affiliate_account WHERE client_id = ?', [$clientId]);

        return $id ? $this->getAffiliate($id) : null;
    }

    public function getAffiliateByCode(string $code): ?array
    {
        if (!preg_match('/^[A-Za-z0-9_-]{3,32}$/', $code)) {
            return null;
        }
        $id = (int) $this->di['db']->getCell('SELECT id FROM affiliate_account WHERE code = ?', [$code]);

        return $id ? $this->getAffiliate($id) : null;
    }

    private function generateCode(): string
    {
        $alphabet = 'abcdefghjkmnpqrstuvwxyz23456789';
        for ($try = 0; $try < 20; ++$try) {
            $code = '';
            for ($i = 0; $i < 8; ++$i) {
                $code .= $alphabet[random_int(0, strlen($alphabet) - 1)];
            }
            if (!$this->di['db']->getCell('SELECT id FROM affiliate_account WHERE code = ?', [$code])) {
                return $code;
            }
        }
        throw new InformationException('Could not generate a unique affiliate code, please try again.');
    }

    private function validateCode(string $code, int $ignoreId = 0): string
    {
        if (!preg_match('/^[A-Za-z0-9_-]{3,32}$/', $code)) {
            throw new InformationException('Code must be 3-32 characters: letters, numbers, dash or underscore.');
        }
        $exists = (int) $this->di['db']->getCell('SELECT id FROM affiliate_account WHERE code = ? AND id <> ?', [$code, $ignoreId]);
        if ($exists) {
            throw new InformationException('This affiliate code is already in use.');
        }

        return $code;
    }

    public function joinProgram(int $clientId, bool $acceptedTerms): array
    {
        $s = $this->getSettings();
        if (!$s['enabled'] || $s['registration'] === 'closed') {
            throw new InformationException('The affiliate program is not accepting new members.');
        }
        if ($this->getAffiliateByClient($clientId)) {
            throw new InformationException('You are already registered in the affiliate program.');
        }
        if ($s['terms_url'] !== '' && !$acceptedTerms) {
            throw new InformationException('You must accept the affiliate terms to join.');
        }

        $status = $s['registration'] === 'open' ? 'active' : 'pending';
        $id = $this->insertRow('affiliate_account', [
            'client_id' => $clientId,
            'code' => $this->generateCode(),
            'status' => $status,
            'terms_accepted_at' => $acceptedTerms ? $this->now() : null,
            'approved_at' => $status === 'active' ? $this->now() : null,
            'created_at' => $this->now(),
            'updated_at' => $this->now(),
        ]);
        $this->notify($id, 'mod_affiliate_status', ['affiliate_status' => $status]);

        return $this->getAffiliate($id);
    }

    public function createAffiliate(int $clientId, ?string $code = null): array
    {
        if (!$this->di['db']->getCell('SELECT id FROM client WHERE id = ?', [$clientId])) {
            throw new InformationException('Client not found.');
        }
        if ($this->getAffiliateByClient($clientId)) {
            throw new InformationException('This client is already an affiliate.');
        }
        $code = ($code !== null && $code !== '') ? $this->validateCode($code) : $this->generateCode();
        $id = $this->insertRow('affiliate_account', [
            'client_id' => $clientId,
            'code' => $code,
            'status' => 'active',
            'approved_at' => $this->now(),
            'created_at' => $this->now(),
            'updated_at' => $this->now(),
        ]);
        $this->notify($id, 'mod_affiliate_status', ['affiliate_status' => 'active']);

        return $this->getAffiliate($id);
    }

    public function updateAffiliate(int $id, array $data): bool
    {
        $aff = $this->getAffiliate($id);
        if (!$aff) {
            throw new InformationException('Affiliate not found.');
        }
        $row = [];

        if (isset($data['code']) && $data['code'] !== '' && $data['code'] !== $aff['code']) {
            $row['code'] = $this->validateCode((string) $data['code'], $id);
        }
        if (array_key_exists('commission_type', $data)) {
            $type = (string) $data['commission_type'];
            if ($type === '') {
                $row['commission_type'] = null;
                $row['commission_value'] = null;
            } elseif (in_array($type, ['percent', 'fixed'], true)) {
                $value = $this->money($data['commission_value'] ?? 0);
                if ($value < 0 || ($type === 'percent' && $value > 100)) {
                    throw new InformationException('Invalid commission value.');
                }
                $row['commission_type'] = $type;
                $row['commission_value'] = $value;
            } else {
                throw new InformationException('Invalid commission type.');
            }
        }
        if (array_key_exists('payout_method', $data)) {
            $method = (string) $data['payout_method'];
            if ($method !== '' && !in_array($method, self::PAYOUT_METHODS, true)) {
                throw new InformationException('Invalid payout method.');
            }
            $row['payout_method'] = $method ?: null;
        }
        if (array_key_exists('payout_details', $data)) {
            $row['payout_details'] = mb_substr(trim((string) $data['payout_details']), 0, 2000);
        }
        if (array_key_exists('notes', $data)) {
            $row['notes'] = mb_substr(trim((string) $data['notes']), 0, 5000);
        }

        if ($row) {
            $row['updated_at'] = $this->now();
            $this->updateRow('affiliate_account', $id, $row);
        }
        if (!empty($data['status']) && $data['status'] !== $aff['status']) {
            $this->setAffiliateStatus($id, (string) $data['status']);
        }

        return true;
    }

    public function setAffiliateStatus(int $id, string $status): bool
    {
        if (!in_array($status, self::AFFILIATE_STATUSES, true)) {
            throw new InformationException('Invalid status.');
        }
        $aff = $this->getAffiliate($id);
        if (!$aff) {
            throw new InformationException('Affiliate not found.');
        }
        $row = ['status' => $status, 'updated_at' => $this->now()];
        if ($status === 'active' && empty($aff['approved_at'])) {
            $row['approved_at'] = $this->now();
        }
        $this->updateRow('affiliate_account', $id, $row);
        $this->notify($id, 'mod_affiliate_status', ['affiliate_status' => $status]);

        return true;
    }

    public function deleteAffiliate(int $id): bool
    {
        if (!$this->getAffiliate($id)) {
            throw new InformationException('Affiliate not found.');
        }
        $pending = (int) $this->di['db']->getCell("SELECT COUNT(*) FROM affiliate_payout WHERE affiliate_id = ? AND status = 'pending'", [$id]);
        if ($pending > 0) {
            throw new InformationException('Resolve the pending payout requests before deleting this affiliate.');
        }
        foreach (['affiliate_commission', 'affiliate_invoice', 'affiliate_payout', 'affiliate_referral', 'affiliate_visit'] as $table) {
            $this->di['db']->exec('DELETE FROM ' . $table . ' WHERE affiliate_id = ?', [$id]);
        }
        $this->di['db']->exec('DELETE FROM affiliate_account WHERE id = ?', [$id]);

        return true;
    }

    public function updatePayoutSettings(int $affiliateId, string $method, string $details): bool
    {
        $allowed = $this->getSettings()['payout_methods'];
        if (!in_array($method, $allowed, true)) {
            throw new InformationException('This payout method is not available.');
        }
        $details = mb_substr(trim($details), 0, 2000);
        if ($method !== 'credit' && $details === '') {
            throw new InformationException('Please provide your payout details.');
        }
        $this->updateRow('affiliate_account', $affiliateId, [
            'payout_method' => $method,
            'payout_details' => $details,
            'updated_at' => $this->now(),
        ]);

        return true;
    }

    public function getAffiliateList(array $data): array
    {
        $where = ['1=1'];
        $params = [];
        if (!empty($data['status']) && in_array($data['status'], self::AFFILIATE_STATUSES, true)) {
            $where[] = 'a.status = ?';
            $params[] = $data['status'];
        }
        if (!empty($data['search'])) {
            $like = '%' . trim((string) $data['search']) . '%';
            $where[] = '(a.code LIKE ? OR c.email LIKE ? OR c.first_name LIKE ? OR c.last_name LIKE ?)';
            array_push($params, $like, $like, $like, $like);
        }

        $sql = "SELECT a.id, a.client_id, a.code, a.status, a.commission_type, a.commission_value, a.payout_method, a.created_at,
                    c.first_name, c.last_name, c.email,
                    (SELECT COUNT(*) FROM affiliate_visit v WHERE v.affiliate_id = a.id) AS clicks,
                    (SELECT COUNT(DISTINCT COALESCE(v2.visitor_id, v2.ip_hash)) FROM affiliate_visit v2 WHERE v2.affiliate_id = a.id) AS unique_clicks,
                    (SELECT COUNT(*) FROM affiliate_invoice p WHERE p.affiliate_id = a.id AND p.status = 'counted') AS purchases,
                    (SELECT COUNT(*) FROM affiliate_referral r WHERE r.affiliate_id = a.id) AS referrals,
                    (SELECT COALESCE(SUM(m.amount), 0) FROM affiliate_commission m WHERE m.affiliate_id = a.id AND m.status IN ('pending','approved','paid')) AS earned
                FROM affiliate_account a LEFT JOIN client c ON c.id = a.client_id
                WHERE " . implode(' AND ', $where) . ' ORDER BY a.id DESC';

        return $this->paginate($sql, $params, $data);
    }

    public function getAffiliateDetail(int $id): array
    {
        $aff = $this->getAffiliate($id);
        if (!$aff) {
            throw new InformationException('Affiliate not found.');
        }
        $aff['balance'] = $this->getBalance($id);
        $aff['stats'] = $this->getAffiliateStats($id);
        $aff['currency'] = $this->getDefaultCurrencyCode();

        return $aff;
    }

    public function getAffiliateStats(int $id): array
    {
        $db = $this->di['db'];
        $clicks = (int) $db->getCell('SELECT COUNT(*) FROM affiliate_visit WHERE affiliate_id = ?', [$id]);
        $unique = (int) $db->getCell('SELECT COUNT(DISTINCT COALESCE(visitor_id, ip_hash)) FROM affiliate_visit WHERE affiliate_id = ?', [$id]);
        $signups = (int) $db->getCell('SELECT COUNT(*) FROM affiliate_referral WHERE affiliate_id = ?', [$id]);
        $paying = (int) $db->getCell("SELECT COUNT(DISTINCT referral_id) FROM affiliate_invoice WHERE affiliate_id = ? AND status = 'counted'", [$id]);
        $purchases = (int) $db->getCell("SELECT COUNT(*) FROM affiliate_invoice WHERE affiliate_id = ? AND status = 'counted'", [$id]);
        $sales = $this->money($db->getCell("SELECT COALESCE(SUM(base_amount), 0) FROM affiliate_invoice WHERE affiliate_id = ? AND status = 'counted'", [$id]));

        return [
            'clicks' => $clicks,
            'unique_clicks' => $unique,
            'signups' => $signups,
            'paying_referrals' => $paying,
            'purchases' => $purchases,
            'sales' => $sales,
            'conversion_rate' => $unique > 0 ? round(min($signups, $unique) / $unique * 100, 2) : 0.0,
            'purchase_rate' => $signups > 0 ? round($paying / $signups * 100, 2) : 0.0,
        ];
    }

    /* ---------------------------------------------------------------------
     * Tracking & attribution
     * ------------------------------------------------------------------ */

    /**
     * Records a click. Returns null if the code is invalid/inactive, otherwise
     * ['affiliate' => row, 'counted' => bool, 'visitor_id' => string].
     *
     * Every real (non-bot) click is stored; only an immediate refresh / double click by the same visitor within
     * CLICK_DEDUPE_SECONDS is ignored. "Unique" clicks are counted per visitor id, not per IP, so visitors behind
     * a shared IP, proxy or CDN no longer collapse into a single click.
     */
    public function trackVisit(string $code, string $landing = ''): ?array
    {
        $s = $this->getSettings();
        if (!$s['enabled']) {
            return null;
        }
        $aff = $this->getAffiliateByCode($code);
        if (!$aff || $aff['status'] !== 'active') {
            return null;
        }

        $visitorId = $this->resolveVisitorId();
        $result = ['affiliate' => $aff, 'counted' => false, 'visitor_id' => $visitorId];

        if ($this->isNonHumanRequest()) {
            return $result;
        }

        $db = $this->di['db'];
        $since = date('Y-m-d H:i:s', time() - self::CLICK_DEDUPE_SECONDS);
        if ($this->hasVisitorCookie()) {
            $recent = (int) $db->getCell(
                'SELECT COUNT(*) FROM affiliate_visit WHERE affiliate_id = ? AND visitor_id = ? AND created_at > ?',
                [(int) $aff['id'], $visitorId, $since]
            );
        } else {
            // No cookie yet (first click, or cookies blocked): only ignore an immediate refresh from the same IP + browser.
            $recent = (int) $db->getCell(
                'SELECT COUNT(*) FROM affiliate_visit WHERE affiliate_id = ? AND ip_hash = ? AND user_agent = ? AND created_at > ?',
                [(int) $aff['id'], $this->ipHash(), substr((string) ($_SERVER['HTTP_USER_AGENT'] ?? ''), 0, 255), $since]
            );
        }
        if ($recent > 0) {
            return $result;
        }
        $seen = (int) $db->getCell('SELECT COUNT(*) FROM affiliate_visit WHERE affiliate_id = ? AND visitor_id = ?', [(int) $aff['id'], $visitorId]);

        $this->insertRow('affiliate_visit', [
            'affiliate_id' => (int) $aff['id'],
            'ip_hash' => $this->ipHash(),
            'user_agent' => substr((string) ($_SERVER['HTTP_USER_AGENT'] ?? ''), 0, 255),
            'referer' => substr((string) ($_SERVER['HTTP_REFERER'] ?? ''), 0, 255),
            'landing' => substr($landing, 0, 255),
            'visitor_id' => $visitorId,
            'is_unique' => $seen > 0 ? 0 : 1,
            'created_at' => $this->now(),
        ]);
        $result['counted'] = true;

        // Public traffic keeps the safety net running even when cron/hooks are not set up.
        $this->maybeSync();

        return $result;
    }

    /** Called after a client signs up: ties them to the affiliate stored in the cookie (or, failing that, a recent click from the same IP). */
    public function attributeSignup(int $clientId): ?int
    {
        $s = $this->getSettings();
        if (!$s['enabled']) {
            return null;
        }
        $db = $this->di['db'];
        if ($db->getCell('SELECT id FROM affiliate_referral WHERE client_id = ?', [$clientId])) {
            return null;
        }

        $code = (string) ($_COOKIE[self::COOKIE_NAME] ?? '');
        if ($code !== '') {
            $aff = $this->getAffiliateByCode($code);
            if ($aff && $aff['status'] === 'active') {
                return $this->createReferral($aff, $clientId, 'cookie');
            }
        }

        // No usable cookie (blocked, expired, other browser/domain): fall back to matching the signup IP.
        return $this->matchSignupByVisit($clientId);
    }

    private function sharesIpWithAffiliate(int $clientId, int $affiliateClientId): bool
    {
        $rows = $this->di['db']->getAll('SELECT id, ip FROM client WHERE id IN (?, ?)', [$clientId, $affiliateClientId]);
        $map = [];
        foreach ($rows as $r) {
            $map[(int) $r['id']] = trim((string) $r['ip']);
        }
        $new = $map[$clientId] ?? '';
        $own = $map[$affiliateClientId] ?? '';

        return $new !== '' && $new === $own;
    }

    private function createReferral(array $aff, int $clientId, string $source, ?int $visitId = null, ?string $createdAt = null): ?int
    {
        if ((int) $aff['client_id'] === $clientId) {
            return null; // self-referral
        }
        if ($this->getSettings()['block_self_referral'] && $this->sharesIpWithAffiliate($clientId, (int) $aff['client_id'])) {
            error_log('Affiliate: signup of client #' . $clientId . ' not attributed (same IP as affiliate, self-referral block is on).');

            return null;
        }

        try {
            return $this->insertRow('affiliate_referral', [
                'affiliate_id' => (int) $aff['id'],
                'client_id' => $clientId,
                'source' => $source,
                'visit_id' => $visitId,
                'created_at' => $createdAt ?? $this->now(),
            ]);
        } catch (\Throwable $e) {
            return null; // already attributed by a concurrent request
        }
    }

    /**
     * Cookie-less attribution: finds a recorded click from the signup IP shortly before the client was created.
     * Honours the first/last-click setting. Disabled by the "ip_fallback" setting.
     */
    public function matchSignupByVisit(int $clientId): ?int
    {
        $s = $this->getSettings();
        if (!$s['enabled'] || !$s['ip_fallback']) {
            return null;
        }
        $db = $this->di['db'];
        if ($db->getCell('SELECT id FROM affiliate_referral WHERE client_id = ?', [$clientId])) {
            return null;
        }
        $client = $db->getRow('SELECT id, ip, created_at FROM client WHERE id = ?', [$clientId]);
        if (!$client || trim((string) $client['ip']) === '') {
            return null;
        }
        $signedUp = strtotime((string) $client['created_at']) ?: time();
        $order = $s['attribution'] === 'first' ? 'ASC' : 'DESC';
        $visits = $db->getAll(
            'SELECT id, affiliate_id FROM affiliate_visit WHERE ip_hash = ? AND created_at >= ? AND created_at <= ? ORDER BY id ' . $order . ' LIMIT 10',
            [
                $this->hashIp(trim((string) $client['ip'])),
                date('Y-m-d H:i:s', $signedUp - self::IP_MATCH_SECONDS),
                date('Y-m-d H:i:s', $signedUp + 600),
            ]
        );
        foreach ($visits as $v) {
            $aff = $this->getAffiliate((int) $v['affiliate_id']);
            if (!$aff || $aff['status'] !== 'active') {
                continue;
            }
            $id = $this->createReferral($aff, $clientId, 'ip_match', (int) $v['id'], date('Y-m-d H:i:s', $signedUp));
            if ($id) {
                return $id;
            }
        }

        return null;
    }

    /** Attributes recent signups that the hook missed (hook not registered, cookie lost). Returns how many were attributed. */
    public function reconcileSignups(int $days = 2, int $limit = 300): int
    {
        $s = $this->getSettings();
        if (!$s['enabled'] || !$s['ip_fallback']) {
            return 0;
        }
        $db = $this->di['db'];
        $since = date('Y-m-d H:i:s', time() - max(1, $days) * 86400);
        $clients = $db->getAll(
            "SELECT c.id, c.ip FROM client c LEFT JOIN affiliate_referral r ON r.client_id = c.id
             WHERE r.id IS NULL AND c.created_at >= ? AND c.ip IS NOT NULL AND c.ip <> '' ORDER BY c.id DESC LIMIT " . max(1, (int) $limit),
            [$since]
        );
        if (!$clients) {
            return 0;
        }
        $byHash = [];
        foreach ($clients as $c) {
            $byHash[$this->hashIp(trim((string) $c['ip']))][] = (int) $c['id'];
        }
        $hashes = array_keys($byHash);
        $matched = $db->getAll(
            'SELECT DISTINCT ip_hash FROM affiliate_visit WHERE created_at >= ? AND ip_hash IN (' . implode(',', array_fill(0, count($hashes), '?')) . ')',
            array_merge([date('Y-m-d H:i:s', time() - (max(1, $days) + 1) * 86400)], $hashes)
        );

        $attributed = 0;
        foreach ($matched as $m) {
            foreach ($byHash[$m['ip_hash']] ?? [] as $clientId) {
                if ($this->matchSignupByVisit($clientId)) {
                    ++$attributed;
                }
            }
        }

        return $attributed;
    }

    /** Admin tool: attach a client to an affiliate by hand (e.g. a signup that could not be tracked). */
    public function assignReferral(int $clientId, int $affiliateId, bool $includePast = false, bool $force = false): int
    {
        $db = $this->di['db'];
        $aff = $this->getAffiliate($affiliateId);
        if (!$aff) {
            throw new InformationException('Affiliate not found.');
        }
        $client = $db->getRow('SELECT id, created_at FROM client WHERE id = ?', [$clientId]);
        if (!$client) {
            throw new InformationException('Client not found.');
        }
        if ((int) $aff['client_id'] === $clientId) {
            throw new InformationException('An affiliate cannot be referred by themselves.');
        }
        $createdAt = ($includePast && !empty($client['created_at'])) ? (string) $client['created_at'] : $this->now();

        $existing = $db->getRow('SELECT id FROM affiliate_referral WHERE client_id = ?', [$clientId]);
        if ($existing) {
            if (!$force) {
                throw new InformationException('This client is already attributed to an affiliate.');
            }
            $this->updateRow('affiliate_referral', (int) $existing['id'], ['affiliate_id' => $affiliateId, 'source' => 'admin']);
            $id = (int) $existing['id'];
        } else {
            $id = $this->insertRow('affiliate_referral', [
                'affiliate_id' => $affiliateId,
                'client_id' => $clientId,
                'source' => 'admin',
                'visit_id' => null,
                'created_at' => $createdAt,
            ]);
        }
        if ($includePast) {
            $this->sweepPaidInvoices(3650, 500, $clientId);
        }

        return $id;
    }

    /* ---------------------------------------------------------------------
     * Self-healing sync: works even when hooks or cron are not registered
     * ------------------------------------------------------------------ */

    /** Runs sync() at most once per $minInterval seconds (and once per request). */
    public function maybeSync(int $minInterval = 60): void
    {
        static $ran = false;
        if ($ran) {
            return;
        }
        $ran = true;

        try {
            $db = $this->di['db'];
            $last = (int) $db->getCell('SELECT setting_value FROM affiliate_setting WHERE setting_key = ?', ['_last_sync']);
            if (time() - $last < $minInterval) {
                return;
            }
            $db->exec('REPLACE INTO affiliate_setting (setting_key, setting_value) VALUES (?, ?)', ['_last_sync', (string) time()]);
            $this->sync(7);
        } catch (\Throwable $e) {
            error_log('Affiliate maybeSync: ' . $e->getMessage());
        }
    }

    /** Attributes missed signups, creates missing commissions for paid invoices and approves due commissions. */
    public function sync(int $days = 7): array
    {
        $out = ['signups_attributed' => 0, 'commissions_created' => 0];
        try {
            $out['signups_attributed'] = $this->reconcileSignups(max(2, min(30, $days)));
        } catch (\Throwable $e) {
            error_log('Affiliate reconcileSignups: ' . $e->getMessage());
        }
        try {
            $out['commissions_created'] = $this->sweepPaidInvoices($days);
        } catch (\Throwable $e) {
            error_log('Affiliate sweepPaidInvoices: ' . $e->getMessage());
        }
        try {
            $this->reconcileRefunds();
        } catch (\Throwable $e) {
            error_log('Affiliate reconcileRefunds: ' . $e->getMessage());
        }
        try {
            $this->approveDueCommissions();
        } catch (\Throwable $e) {
            error_log('Affiliate approveDueCommissions: ' . $e->getMessage());
        }
        $this->di['db']->exec('REPLACE INTO affiliate_setting (setting_key, setting_value) VALUES (?, ?)', ['_last_sync', (string) time()]);

        return $out;
    }

    /**
     * Finds paid invoices of referred clients that have no commission yet and processes them.
     * Idempotent: processPaidInvoice() skips invoices that already have a commission.
     */
    public function sweepPaidInvoices(int $days = 7, int $limit = 500, int $clientId = 0): int
    {
        if (!$this->getSettings()['enabled']) {
            return 0;
        }
        $params = [date('Y-m-d H:i:s', time() - max(1, $days) * 86400)];
        $clientSql = '';
        if ($clientId > 0) {
            $clientSql = ' AND i.client_id = ?';
            $params[] = $clientId;
        }
        $rows = $this->di['db']->getAll(
            "SELECT i.id FROM invoice i
             INNER JOIN affiliate_referral r ON r.client_id = i.client_id
             LEFT JOIN affiliate_invoice m ON m.invoice_id = i.id
             WHERE i.status = 'paid' AND m.id IS NULL
               AND COALESCE(i.paid_at, i.updated_at, i.created_at) >= ?
               AND COALESCE(i.paid_at, i.updated_at, i.created_at) >= r.created_at" . $clientSql . '
             ORDER BY i.id ASC LIMIT ' . max(1, (int) $limit),
            $params
        );

        $created = 0;
        foreach ($rows as $row) {
            try {
                if ($this->processPaidInvoice((int) $row['id'])) {
                    ++$created;
                }
            } catch (\Throwable $e) {
                error_log('Affiliate sweep invoice #' . $row['id'] . ': ' . $e->getMessage());
            }
        }

        return $created;
    }

    /** Health information for the admin "Tracking health" panel. */
    public function getDiagnostics(): array
    {
        $db = $this->di['db'];
        $s = $this->getSettings();

        $events = ['onAfterClientSignUp', 'onAfterAdminInvoicePaymentReceived', 'onAfterAdminInvoiceRefund', 'onBeforeAdminCronRun'];
        $hooks = array_fill_keys($events, null); // null = could not be determined
        try {
            $rows = $db->getAll("SELECT meta_value FROM extension_meta WHERE extension = 'mod_hook' AND rel_id = 'affiliate'");
            if ($rows) {
                $found = [];
                foreach ($rows as $r) {
                    $found[(string) $r['meta_value']] = true;
                }
                foreach ($events as $e) {
                    $hooks[$e] = isset($found[$e]);
                }
            }
        } catch (\Throwable $e) {
        }

        $count = static fn (string $sql, array $p = []) => (int) $db->getCell($sql, $p);
        $since = date('Y-m-d H:i:s', time() - 7 * 86400);

        return [
            'schema_version' => self::SCHEMA_VERSION,
            'system_url' => $this->getSystemUrl(),
            'program_enabled' => (bool) $s['enabled'],
            'ip_fallback' => (bool) $s['ip_fallback'],
            'block_self_referral' => (bool) $s['block_self_referral'],
            'hooks' => $hooks,
            'last_sync' => ($t = (int) $db->getCell('SELECT setting_value FROM affiliate_setting WHERE setting_key = ?', ['_last_sync'])) ? date('Y-m-d H:i:s', $t) : null,
            'clicks_total' => $count('SELECT COUNT(*) FROM affiliate_visit'),
            'referrals_total' => $count('SELECT COUNT(*) FROM affiliate_referral'),
            'referrals_by_ip_match' => $count("SELECT COUNT(*) FROM affiliate_referral WHERE source = 'ip_match'"),
            'commissions_total' => $count("SELECT COUNT(*) FROM affiliate_commission WHERE type = 'commission'"),
            'purchases_total' => $count("SELECT COUNT(*) FROM affiliate_invoice WHERE status = 'counted'"),
            'unattributed_signups_7d' => $count('SELECT COUNT(*) FROM client c LEFT JOIN affiliate_referral r ON r.client_id = c.id WHERE r.id IS NULL AND c.created_at >= ?', [$since]),
            'unprocessed_paid_invoices_7d' => $count(
                "SELECT COUNT(*) FROM invoice i INNER JOIN affiliate_referral r ON r.client_id = i.client_id
                 LEFT JOIN affiliate_invoice m ON m.invoice_id = i.id
                 WHERE i.status = 'paid' AND m.id IS NULL AND COALESCE(i.paid_at, i.updated_at, i.created_at) >= ?",
                [$since]
            ),
        ];
    }

    /* ---------------------------------------------------------------------
     * Commissions
     * ------------------------------------------------------------------ */

    private function resolveDefaultRate(array $aff): array
    {
        if (!empty($aff['commission_type']) && $aff['commission_value'] !== null) {
            return [$aff['commission_type'], (float) $aff['commission_value']];
        }
        $s = $this->getSettings();

        return [$s['commission_type'], (float) $s['commission_value']];
    }

    /**
     * Records a paid invoice of a referred client as a purchase (ledger row, always) and creates the commission (when due).
     * Returns the ledger id of a newly recorded purchase, or null when nothing new was recorded. Idempotent.
     */
    public function processPaidInvoice(int $invoiceId): ?int
    {
        $s = $this->getSettings();
        if (!$s['enabled']) {
            return null;
        }
        $db = $this->di['db'];

        $invoice = $db->getRow('SELECT * FROM invoice WHERE id = ?', [$invoiceId]);
        if (!$invoice || (string) ($invoice['status'] ?? '') !== 'paid') {
            return null;
        }
        $refSql = 'SELECT r.id AS referral_id, r.created_at AS referred_at, r.affiliate_id
                   FROM affiliate_referral r WHERE r.client_id = ?';
        $ref = $db->getRow($refSql, [(int) $invoice['client_id']]);
        if (!$ref) {
            // Signup was not tracked (cookie lost / hook missed): try to match it from the click log, once.
            $this->matchSignupByVisit((int) $invoice['client_id']);
            $ref = $db->getRow($refSql, [(int) $invoice['client_id']]);
        }
        if (!$ref) {
            return null;
        }
        $aff = $this->getAffiliate((int) $ref['affiliate_id']);
        if (!$aff || $aff['status'] !== 'active') {
            return null; // not recorded: picked up later by sync() once the affiliate is active again
        }
        if ($db->getCell('SELECT id FROM affiliate_invoice WHERE invoice_id = ?', [$invoiceId])
            || $db->getCell("SELECT id FROM affiliate_commission WHERE invoice_id = ? AND type = 'commission'", [$invoiceId])) {
            return null; // already processed
        }

        $previous = (int) $db->getCell("SELECT COUNT(*) FROM affiliate_commission WHERE referral_id = ? AND type = 'commission'", [(int) $ref['referral_id']]);
        $eligible = true; // the purchase is always counted; this only decides whether a commission is due
        if ($s['commission_duration'] === 'first' && $previous > 0) {
            $eligible = false;
        }
        if ($s['commission_duration'] === 'months') {
            $limit = strtotime($ref['referred_at'] . ' +' . (int) $s['commission_months'] . ' months');
            if ($limit !== false && time() > $limit) {
                $eligible = false;
            }
        }

        $items = $db->getAll('SELECT type, rel_id, price, quantity FROM invoice_item WHERE invoice_id = ?', [$invoiceId]);
        $productRates = [];
        foreach ($db->getAll('SELECT product_id, rate_type, rate_value FROM affiliate_product_rate') as $r) {
            $productRates[(int) $r['product_id']] = [$r['rate_type'], (float) $r['rate_value']];
        }
        [$defType, $defValue] = $this->resolveDefaultRate($aff);

        // Invoice-level discount (coupons): spread proportionally over the lines so sales/commission are not overstated.
        $linesTotal = 0.0;
        foreach ($items as $item) {
            $linesTotal += max(0.0, (float) $item['price'] * (float) $item['quantity']);
        }
        $discount = max(0.0, (float) ($invoice['discount'] ?? 0));
        $factor = ($linesTotal > 0 && $discount > 0) ? max(0.0, ($linesTotal - $discount) / $linesTotal) : 1.0;

        $base = 0.0;
        $commission = 0.0;
        $defaultFixedApplied = false;
        $usedType = $defType;
        $usedValue = $defValue;

        foreach ($items as $item) {
            $line = (float) $item['price'] * (float) $item['quantity'] * $factor;
            if ($line <= 0) {
                continue;
            }
            if ($item['type'] === 'deposit' && $s['exclude_deposits']) {
                continue;
            }
            $override = null;
            if ($item['type'] === 'order' && !empty($item['rel_id'])) {
                $pid = (int) $db->getCell('SELECT product_id FROM client_order WHERE id = ?', [(int) $item['rel_id']]);
                $override = $productRates[$pid] ?? null;
            }
            if ($override !== null) {
                [$type, $value] = $override;
                if ($value <= 0) {
                    continue; // product excluded from the program
                }
                $commission += $type === 'percent' ? $line * $value / 100 : $value;
            } else {
                $type = $defType;
                $value = $defValue;
                if ($value <= 0) {
                    $base += $line; // still a sale, just no commission at the program rate
                    continue;
                }
                if ($type === 'percent') {
                    $commission += $line * $value / 100;
                } elseif (!$defaultFixedApplied) {
                    $commission += $value;
                    $defaultFixedApplied = true;
                }
            }
            $base += $line;
        }

        $rate = $this->rate((string) $invoice['currency']);
        $baseDefault = $this->money($base / $rate);
        $commissionDefault = $eligible ? $this->money($commission / $rate) : 0.0;

        $hold = (int) $s['hold_days'];
        $status = ($s['approval_mode'] === 'auto' && $hold === 0) ? 'approved' : 'pending';
        $available = date('Y-m-d H:i:s', time() + $hold * 86400);
        $paidAt = (string) ($invoice['paid_at'] ?? '') !== '' ? (string) $invoice['paid_at'] : $this->now();

        // Claim the invoice first (unique key): concurrent requests/hook + cron cannot both create a commission.
        try {
            $ledgerId = $this->insertRow('affiliate_invoice', [
                'invoice_id' => $invoiceId,
                'affiliate_id' => (int) $aff['id'],
                'referral_id' => (int) $ref['referral_id'],
                'client_id' => (int) $invoice['client_id'],
                'status' => 'counted',
                'base_amount' => $baseDefault,
                'commission_amount' => $commissionDefault,
                'paid_at' => $paidAt,
                'created_at' => $this->now(),
                'updated_at' => $this->now(),
            ]);
        } catch (\Throwable $e) {
            return null; // lost a race with a concurrent request for the same invoice
        }

        $firstEver = $previous === 0;

        try {
            if ($commissionDefault >= 0.01) {
                $commissionId = $this->insertCommissionSafe([
                    'affiliate_id' => $aff['id'],
                    'referral_id' => $ref['referral_id'],
                    'client_id' => $invoice['client_id'],
                    'invoice_id' => $invoiceId,
                    'type' => 'commission',
                    'status' => $status,
                    'base_amount' => $baseDefault,
                    'rate_type' => $usedType,
                    'rate_value' => $usedValue,
                    'amount' => $commissionDefault,
                    'description' => 'Invoice #' . $invoiceId,
                    'available_at' => $available,
                    'created_at' => $this->now(),
                    'updated_at' => $this->now(),
                ]);
                if ($commissionId !== null) {
                    $this->notify((int) $aff['id'], 'mod_affiliate_commission', [
                        'commission_amount' => number_format($commissionDefault, 2, '.', ''),
                        'commission_currency' => $this->getDefaultCurrencyCode(),
                        'commission_status' => $status,
                        'hold_days' => $hold,
                    ]);
                }
            }

            if ($eligible && $firstEver && $s['signup_bonus'] > 0 && $baseDefault > 0) {
                $has = $db->getCell("SELECT id FROM affiliate_commission WHERE referral_id = ? AND type = 'signup_bonus'", [(int) $ref['referral_id']]);
                if (!$has) {
                    $this->insertRow('affiliate_commission', [
                        'affiliate_id' => $aff['id'],
                        'referral_id' => $ref['referral_id'],
                        'client_id' => $invoice['client_id'],
                        'invoice_id' => null,
                        'type' => 'signup_bonus',
                        'status' => $status,
                        'base_amount' => 0,
                        'rate_type' => 'fixed',
                        'rate_value' => $s['signup_bonus'],
                        'amount' => $s['signup_bonus'],
                        'description' => 'Signup bonus (first paid invoice #' . $invoiceId . ')',
                        'available_at' => $available,
                        'created_at' => $this->now(),
                        'updated_at' => $this->now(),
                    ]);
                }
            }
        } catch (\Throwable $e) {
            // Release the claim so the next sync retries this invoice instead of losing the commission.
            $db->exec('DELETE FROM affiliate_invoice WHERE id = ?', [$ledgerId]);

            throw $e;
        }

        return $ledgerId;
    }

    /** Insert that survives the unique (invoice_id, type) key when two requests process the same invoice. */
    private function insertCommissionSafe(array $row): ?int
    {
        try {
            return $this->insertRow('affiliate_commission', $row);
        } catch (\Throwable $e) {
            if ($this->di['db']->getCell("SELECT id FROM affiliate_commission WHERE invoice_id = ? AND type = 'commission'", [(int) $row['invoice_id']])) {
                return null;
            }

            throw $e;
        }
    }

    /** Finds invoices refunded after they were counted (the refund hook can be missed) and reverses them. */
    public function reconcileRefunds(int $limit = 200): int
    {
        $rows = $this->di['db']->getAll(
            "SELECT l.invoice_id FROM affiliate_invoice l INNER JOIN invoice i ON i.id = l.invoice_id
             WHERE l.status = 'counted' AND i.status = 'refunded' ORDER BY l.id ASC LIMIT " . max(1, $limit)
        );
        $n = 0;
        foreach ($rows as $row) {
            try {
                $this->reverseInvoiceCommissions((int) $row['invoice_id']);
                ++$n;
            } catch (\Throwable $e) {
                error_log('Affiliate reconcileRefunds invoice #' . $row['invoice_id'] . ': ' . $e->getMessage());
            }
        }

        return $n;
    }

    public function reverseInvoiceCommissions(int $invoiceId): int
    {
        $db = $this->di['db'];
        if ((string) $db->getCell('SELECT status FROM invoice WHERE id = ?', [$invoiceId]) !== 'refunded') {
            return 0; // only full refunds are clawed back automatically
        }
        // A fully refunded invoice is no longer a purchase, whatever the clawback setting is.
        $db->exec("UPDATE affiliate_invoice SET status = 'refunded', updated_at = ? WHERE invoice_id = ? AND status = 'counted'", [$this->now(), $invoiceId]);
        if (!$this->getSettings()['clawback_on_refund']) {
            return 0;
        }
        $rows = $db->getAll("SELECT * FROM affiliate_commission WHERE invoice_id = ? AND type = 'commission' AND status IN ('pending','approved','paid')", [$invoiceId]);
        $count = 0;
        foreach ($rows as $row) {
            $direct = $row['status'] === 'pending' || ($row['status'] === 'approved' && empty($row['payout_id']));
            if ($direct) {
                $this->updateRow('affiliate_commission', (int) $row['id'], ['status' => 'reversed', 'updated_at' => $this->now()]);
            } else {
                $this->insertRow('affiliate_commission', [
                    'affiliate_id' => $row['affiliate_id'],
                    'referral_id' => $row['referral_id'],
                    'client_id' => $row['client_id'],
                    'invoice_id' => null,
                    'type' => 'adjustment',
                    'status' => 'approved',
                    'base_amount' => 0,
                    'rate_type' => null,
                    'rate_value' => null,
                    'amount' => -1 * (float) $row['amount'],
                    'description' => 'Refund clawback for invoice #' . $invoiceId,
                    'available_at' => $this->now(),
                    'created_at' => $this->now(),
                    'updated_at' => $this->now(),
                ]);
            }
            ++$count;
        }

        return $count;
    }

    public function approveDueCommissions(): void
    {
        if ($this->getSettings()['approval_mode'] !== 'auto') {
            return;
        }
        $this->di['db']->exec(
            "UPDATE affiliate_commission SET status = 'approved', updated_at = ? WHERE status = 'pending' AND available_at <= ?",
            [$this->now(), $this->now()]
        );
    }

    public function getCommission(int $id): ?array
    {
        $row = $this->di['db']->getRow('SELECT * FROM affiliate_commission WHERE id = ?', [$id]);

        return $row ?: null;
    }

    public function setCommissionStatus(int $id, string $action): bool
    {
        $c = $this->getCommission($id);
        if (!$c) {
            throw new InformationException('Commission not found.');
        }
        if ($action === 'approve') {
            if ($c['status'] !== 'pending') {
                throw new InformationException('Only pending commissions can be approved.');
            }
            $this->updateRow('affiliate_commission', $id, ['status' => 'approved', 'updated_at' => $this->now()]);
        } elseif ($action === 'reject') {
            $ok = $c['status'] === 'pending' || ($c['status'] === 'approved' && empty($c['payout_id']));
            if (!$ok) {
                throw new InformationException('This commission can no longer be rejected (it is part of a payout).');
            }
            $this->updateRow('affiliate_commission', $id, ['status' => 'rejected', 'updated_at' => $this->now()]);
        } else {
            throw new InformationException('Unknown action.');
        }

        return true;
    }

    public function createManualCommission(int $affiliateId, float $amount, string $description, bool $approved = true): int
    {
        if (!$this->getAffiliate($affiliateId)) {
            throw new InformationException('Affiliate not found.');
        }
        $amount = $this->money($amount);
        if ($amount == 0.0) {
            throw new InformationException('Amount cannot be zero.');
        }

        return $this->insertRow('affiliate_commission', [
            'affiliate_id' => $affiliateId,
            'type' => 'adjustment',
            'status' => $approved ? 'approved' : 'pending',
            'base_amount' => 0,
            'amount' => $amount,
            'description' => mb_substr(trim($description) ?: 'Manual adjustment', 0, 255),
            'available_at' => $this->now(),
            'created_at' => $this->now(),
            'updated_at' => $this->now(),
        ]);
    }

    public function getCommissionList(array $data): array
    {
        $where = ['1=1'];
        $params = [];
        if (!empty($data['status'])) {
            $where[] = 'm.status = ?';
            $params[] = $data['status'];
        }
        if (!empty($data['type'])) {
            $where[] = 'm.type = ?';
            $params[] = $data['type'];
        }
        if (!empty($data['affiliate_id'])) {
            $where[] = 'm.affiliate_id = ?';
            $params[] = (int) $data['affiliate_id'];
        }
        if (!empty($data['invoice_id'])) {
            $where[] = 'm.invoice_id = ?';
            $params[] = (int) $data['invoice_id'];
        }
        $sql = "SELECT m.id, m.affiliate_id, m.client_id, m.invoice_id, m.payout_id, m.type, m.status, m.base_amount, m.rate_type,
                    m.rate_value, m.amount, m.description, m.available_at, m.created_at,
                    a.code AS affiliate_code, c.first_name, c.last_name, c.email
                FROM affiliate_commission m
                LEFT JOIN affiliate_account a ON a.id = m.affiliate_id
                LEFT JOIN client c ON c.id = a.client_id
                WHERE " . implode(' AND ', $where) . ' ORDER BY m.id DESC';
        $res = $this->paginate($sql, $params, $data);
        $cur = $this->getDefaultCurrencyCode();
        foreach ($res['list'] as &$r) {
            $r['currency'] = $cur;
        }

        return $res;
    }

    /* ---------------------------------------------------------------------
     * Balance & payouts
     * ------------------------------------------------------------------ */

    public function getBalance(int $affiliateId): array
    {
        $this->approveDueCommissions();
        $row = $this->di['db']->getRow(
            "SELECT
                COALESCE(SUM(CASE WHEN status = 'pending' THEN amount END), 0) AS pending,
                COALESCE(SUM(CASE WHEN status = 'approved' AND payout_id IS NULL THEN amount END), 0) AS available,
                COALESCE(SUM(CASE WHEN status = 'approved' AND payout_id IS NOT NULL THEN amount END), 0) AS in_payout,
                COALESCE(SUM(CASE WHEN status = 'paid' THEN amount END), 0) AS paid,
                COALESCE(SUM(CASE WHEN status IN ('pending','approved','paid') THEN amount END), 0) AS lifetime
             FROM affiliate_commission WHERE affiliate_id = ?",
            [$affiliateId]
        ) ?: [];

        $out = [];
        foreach (['pending', 'available', 'in_payout', 'paid', 'lifetime'] as $k) {
            $out[$k] = $this->money($row[$k] ?? 0);
        }
        $out['currency'] = $this->getDefaultCurrencyCode();

        return $out;
    }

    public function requestPayout(int $affiliateId): array
    {
        $aff = $this->getAffiliate($affiliateId);
        if (!$aff || $aff['status'] !== 'active') {
            throw new InformationException('Your affiliate account is not active.');
        }
        $this->approveDueCommissions();
        $s = $this->getSettings();
        $method = (string) $aff['payout_method'];
        if ($method === '' || !in_array($method, $s['payout_methods'], true)) {
            throw new InformationException('Please choose a payout method first.');
        }
        if ($method !== 'credit' && trim((string) $aff['payout_details']) === '') {
            throw new InformationException('Please provide your payout details first.');
        }

        $payoutId = $this->insertRow('affiliate_payout', [
            'affiliate_id' => $affiliateId,
            'amount' => 0,
            'method' => $method,
            'details' => $aff['payout_details'],
            'status' => 'pending',
            'created_at' => $this->now(),
            'updated_at' => $this->now(),
        ]);

        // Claim all currently available commissions for this payout.
        $db = $this->di['db'];
        $db->exec(
            "UPDATE affiliate_commission SET payout_id = ?, updated_at = ? WHERE affiliate_id = ? AND status = 'approved' AND payout_id IS NULL",
            [$payoutId, $this->now(), $affiliateId]
        );
        $sum = $this->money($db->getCell('SELECT COALESCE(SUM(amount), 0) FROM affiliate_commission WHERE payout_id = ?', [$payoutId]));

        if ($sum <= 0 || $sum < (float) $s['min_payout']) {
            $db->exec('UPDATE affiliate_commission SET payout_id = NULL WHERE payout_id = ?', [$payoutId]);
            $db->exec('DELETE FROM affiliate_payout WHERE id = ?', [$payoutId]);

            throw new InformationException(sprintf('The minimum payout is %s %s. Your available balance is %s.', number_format((float) $s['min_payout'], 2), $this->getDefaultCurrencyCode(), number_format(max(0, $sum), 2)));
        }

        $this->updateRow('affiliate_payout', $payoutId, ['amount' => $sum, 'updated_at' => $this->now()]);

        return $this->getPayout($payoutId);
    }

    public function getPayout(int $id): ?array
    {
        $row = $this->di['db']->getRow(
            'SELECT p.*, a.code AS affiliate_code, a.client_id, c.first_name, c.last_name, c.email, c.currency AS client_currency
             FROM affiliate_payout p
             LEFT JOIN affiliate_account a ON a.id = p.affiliate_id
             LEFT JOIN client c ON c.id = a.client_id
             WHERE p.id = ?',
            [$id]
        );
        if ($row) {
            $row['currency'] = $this->getDefaultCurrencyCode();
        }

        return $row ?: null;
    }

    public function getPayoutList(array $data): array
    {
        $where = ['1=1'];
        $params = [];
        if (!empty($data['status'])) {
            $where[] = 'p.status = ?';
            $params[] = $data['status'];
        }
        if (!empty($data['affiliate_id'])) {
            $where[] = 'p.affiliate_id = ?';
            $params[] = (int) $data['affiliate_id'];
        }
        $sql = "SELECT p.id, p.affiliate_id, p.amount, p.method, p.details, p.status, p.transaction_ref, p.admin_note, p.processed_at, p.created_at,
                    a.code AS affiliate_code, c.first_name, c.last_name, c.email
                FROM affiliate_payout p
                LEFT JOIN affiliate_account a ON a.id = p.affiliate_id
                LEFT JOIN client c ON c.id = a.client_id
                WHERE " . implode(' AND ', $where) . ' ORDER BY p.id DESC';
        $res = $this->paginate($sql, $params, $data);
        $cur = $this->getDefaultCurrencyCode();
        foreach ($res['list'] as &$r) {
            $r['currency'] = $cur;
        }

        return $res;
    }

    public function markPayoutPaid(int $id, string $reference = '', string $note = ''): bool
    {
        $p = $this->getPayout($id);
        if (!$p) {
            throw new InformationException('Payout not found.');
        }
        if ($p['status'] !== 'pending') {
            throw new InformationException('Only pending payouts can be marked as paid.');
        }

        if ($p['method'] === 'credit') {
            $clientCurrency = (string) ($p['client_currency'] ?: $this->getDefaultCurrencyCode());
            $amount = $this->money((float) $p['amount'] * $this->rate($clientCurrency));
            $this->di['db']->exec(
                'INSERT INTO client_balance (client_id, type, rel_id, amount, description, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?)',
                [(int) $p['client_id'], 'affiliate', $id, $amount, 'Affiliate payout #' . $id, $this->now(), $this->now()]
            );
            $reference = $reference !== '' ? $reference : 'Account credit';
        }

        $this->updateRow('affiliate_payout', $id, [
            'status' => 'paid',
            'transaction_ref' => mb_substr($reference, 0, 255),
            'admin_note' => mb_substr($note, 0, 5000),
            'processed_at' => $this->now(),
            'updated_at' => $this->now(),
        ]);
        $this->di['db']->exec("UPDATE affiliate_commission SET status = 'paid', updated_at = ? WHERE payout_id = ? AND status = 'approved'", [$this->now(), $id]);

        $this->notify((int) $p['affiliate_id'], 'mod_affiliate_payout', [
            'payout_status' => 'paid',
            'payout_amount' => number_format((float) $p['amount'], 2, '.', ''),
            'payout_currency' => $p['currency'],
            'payout_method' => $p['method'],
            'payout_reference' => $reference,
            'payout_note' => $note,
        ]);

        return true;
    }

    public function rejectPayout(int $id, string $note = ''): bool
    {
        $p = $this->getPayout($id);
        if (!$p) {
            throw new InformationException('Payout not found.');
        }
        if ($p['status'] !== 'pending') {
            throw new InformationException('Only pending payouts can be rejected.');
        }
        $this->releasePayout($id, 'rejected', $note);
        $this->notify((int) $p['affiliate_id'], 'mod_affiliate_payout', [
            'payout_status' => 'rejected',
            'payout_amount' => number_format((float) $p['amount'], 2, '.', ''),
            'payout_currency' => $p['currency'],
            'payout_method' => $p['method'],
            'payout_reference' => '',
            'payout_note' => $note,
        ]);

        return true;
    }

    public function cancelPayout(int $id, int $affiliateId): bool
    {
        $p = $this->getPayout($id);
        if (!$p || (int) $p['affiliate_id'] !== $affiliateId) {
            throw new InformationException('Payout not found.');
        }
        if ($p['status'] !== 'pending') {
            throw new InformationException('Only pending payouts can be cancelled.');
        }
        $this->releasePayout($id, 'cancelled', 'Cancelled by affiliate');

        return true;
    }

    private function releasePayout(int $id, string $status, string $note): void
    {
        $this->di['db']->exec('UPDATE affiliate_commission SET payout_id = NULL, updated_at = ? WHERE payout_id = ?', [$this->now(), $id]);
        $this->updateRow('affiliate_payout', $id, [
            'status' => $status,
            'admin_note' => mb_substr($note, 0, 5000),
            'processed_at' => $this->now(),
            'updated_at' => $this->now(),
        ]);
    }

    /* ---------------------------------------------------------------------
     * Referrals
     * ------------------------------------------------------------------ */

    public function getReferralList(array $data): array
    {
        $where = ['1=1'];
        $params = [];
        if (!empty($data['affiliate_id'])) {
            $where[] = 'r.affiliate_id = ?';
            $params[] = (int) $data['affiliate_id'];
        }
        $sql = "SELECT r.id, r.affiliate_id, r.client_id, r.created_at,
                    a.code AS affiliate_code,
                    c.first_name, c.last_name, c.email,
                    (SELECT COALESCE(SUM(m.amount), 0) FROM affiliate_commission m WHERE m.referral_id = r.id AND m.status IN ('pending','approved','paid')) AS earned
                FROM affiliate_referral r
                LEFT JOIN affiliate_account a ON a.id = r.affiliate_id
                LEFT JOIN client c ON c.id = r.client_id
                WHERE " . implode(' AND ', $where) . ' ORDER BY r.id DESC';

        return $this->paginate($sql, $params, $data);
    }

    /** Same data as above, but personal details are masked for the affiliate. */
    public function getClientReferralList(int $affiliateId, array $data): array
    {
        $res = $this->getReferralList(array_merge($data, ['affiliate_id' => $affiliateId]));
        $list = [];
        foreach ($res['list'] as $r) {
            $list[] = [
                'id' => $r['id'],
                'display' => $this->maskName((string) $r['first_name'], (string) $r['last_name']),
                'email' => $this->maskEmail((string) $r['email']),
                'created_at' => $r['created_at'],
                'earned' => $this->money($r['earned']),
                'currency' => $this->getDefaultCurrencyCode(),
            ];
        }
        $res['list'] = $list;

        return $res;
    }

    private function maskName(string $first, string $last): string
    {
        $f = mb_substr($first, 0, 1);
        $l = mb_substr($last, 0, 1);

        return trim($f . '*** ' . ($l !== '' ? $l . '.' : ''));
    }

    private function maskEmail(string $email): string
    {
        $parts = explode('@', $email, 2);
        if (count($parts) !== 2) {
            return '***';
        }

        return mb_substr($parts[0], 0, 1) . '***@' . mb_substr($parts[1], 0, 1) . '***';
    }

    /* ---------------------------------------------------------------------
     * Product commission overrides
     * ------------------------------------------------------------------ */

    public function getProductRates(): array
    {
        return $this->di['db']->getAll(
            'SELECT r.id, r.product_id, r.rate_type, r.rate_value, p.title AS product_title
             FROM affiliate_product_rate r LEFT JOIN product p ON p.id = r.product_id ORDER BY p.title ASC'
        );
    }

    public function setProductRate(int $productId, string $type, float $value): bool
    {
        if (!in_array($type, ['percent', 'fixed'], true) || $value < 0 || ($type === 'percent' && $value > 100)) {
            throw new InformationException('Invalid commission rate.');
        }
        if (!$this->di['db']->getCell('SELECT id FROM product WHERE id = ?', [$productId])) {
            throw new InformationException('Product not found.');
        }
        $this->di['db']->exec(
            'INSERT INTO affiliate_product_rate (product_id, rate_type, rate_value, created_at, updated_at) VALUES (?, ?, ?, ?, ?)
             ON DUPLICATE KEY UPDATE rate_type = VALUES(rate_type), rate_value = VALUES(rate_value), updated_at = VALUES(updated_at)',
            [$productId, $type, $this->money($value), $this->now(), $this->now()]
        );

        return true;
    }

    public function deleteProductRate(int $productId): bool
    {
        $this->di['db']->exec('DELETE FROM affiliate_product_rate WHERE product_id = ?', [$productId]);

        return true;
    }

    /* ---------------------------------------------------------------------
     * Dashboard statistics (admin)
     * ------------------------------------------------------------------ */

    public function getStats(): array
    {
        $this->maybeSync(15);
        $db = $this->di['db'];
        $since = date('Y-m-d H:i:s', time() - 30 * 86400);

        $byStatus = [];
        foreach ($db->getAll('SELECT status, COUNT(*) AS total FROM affiliate_account GROUP BY status') as $r) {
            $byStatus[$r['status']] = (int) $r['total'];
        }
        $comm = $db->getRow(
            "SELECT
                COALESCE(SUM(CASE WHEN status = 'pending' THEN amount END), 0) AS pending,
                COALESCE(SUM(CASE WHEN status = 'approved' THEN amount END), 0) AS approved,
                COALESCE(SUM(CASE WHEN status = 'paid' THEN amount END), 0) AS paid
             FROM affiliate_commission"
        ) ?: [];
        $payouts = $db->getRow("SELECT COUNT(*) AS total, COALESCE(SUM(amount), 0) AS amount FROM affiliate_payout WHERE status = 'pending'") ?: [];

        $top = $db->getAll(
            "SELECT a.id, a.code, c.first_name, c.last_name, c.email,
                (SELECT COUNT(*) FROM affiliate_referral r WHERE r.affiliate_id = a.id) AS referrals,
                (SELECT COALESCE(SUM(m.amount), 0) FROM affiliate_commission m WHERE m.affiliate_id = a.id AND m.status IN ('pending','approved','paid')) AS earned
             FROM affiliate_account a LEFT JOIN client c ON c.id = a.client_id
             WHERE a.status = 'active' ORDER BY earned DESC LIMIT 5"
        );

        return [
            'currency' => $this->getDefaultCurrencyCode(),
            'affiliates' => [
                'active' => $byStatus['active'] ?? 0,
                'pending' => $byStatus['pending'] ?? 0,
                'suspended' => $byStatus['suspended'] ?? 0,
                'rejected' => $byStatus['rejected'] ?? 0,
            ],
            'clicks_total' => (int) $db->getCell('SELECT COUNT(*) FROM affiliate_visit'),
            'clicks_30d' => (int) $db->getCell('SELECT COUNT(*) FROM affiliate_visit WHERE created_at >= ?', [$since]),
            'referrals_total' => (int) $db->getCell('SELECT COUNT(*) FROM affiliate_referral'),
            'referrals_30d' => (int) $db->getCell('SELECT COUNT(*) FROM affiliate_referral WHERE created_at >= ?', [$since]),
            'purchases_total' => (int) $db->getCell("SELECT COUNT(*) FROM affiliate_invoice WHERE status = 'counted'"),
            'purchases_30d' => (int) $db->getCell("SELECT COUNT(*) FROM affiliate_invoice WHERE status = 'counted' AND paid_at >= ?", [$since]),
            'commissions' => [
                'pending' => $this->money($comm['pending'] ?? 0),
                'approved' => $this->money($comm['approved'] ?? 0),
                'paid' => $this->money($comm['paid'] ?? 0),
            ],
            'payouts_pending_count' => (int) ($payouts['total'] ?? 0),
            'payouts_pending_amount' => $this->money($payouts['amount'] ?? 0),
            'top_affiliates' => $top,
        ];
    }
}
