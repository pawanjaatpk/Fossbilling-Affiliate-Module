<?php

/**
 * Affiliate module for FOSSBilling - public API.
 * Licensed under the Apache License, Version 2.0
 */

namespace Box\Mod\Affiliate\Api;

use FOSSBilling\Api\AbstractApi;

class Guest extends AbstractApi
{
    /** Public program terms - safe to show on a marketing page. */
    public function get_program(array $data): array
    {
        return $this->getService()->getPublicProgram();
    }
}
