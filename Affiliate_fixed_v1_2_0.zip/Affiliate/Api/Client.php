<?php

/**
 * Affiliate module for FOSSBilling - client API (logged-in clients only).
 * Licensed under the Apache License, Version 2.0
 */

namespace Box\Mod\Affiliate\Api;

use FOSSBilling\Api\AbstractApi;
use FOSSBilling\InformationException;

class Client extends AbstractApi
{
    private function affiliate(): array
    {
        $aff = $this->getService()->getAffiliateByClient((int) $this->getIdentity()->id);
        if (!$aff) {
            throw new InformationException('You are not part of the affiliate program.');
        }

        return $aff;
    }

    private function activeAffiliate(): array
    {
        $aff = $this->affiliate();
        if ($aff['status'] !== 'active') {
            throw new InformationException('Your affiliate account is not active.');
        }

        return $aff;
    }

    /** Everything the client area needs to render the affiliate page. */
    public function get_overview(array $data): array
    {
        $service = $this->getService();
        $service->maybeSync(15);
        $program = $service->getPublicProgram();
        $aff = $service->getAffiliateByClient((int) $this->getIdentity()->id);

        $out = ['is_affiliate' => (bool) $aff, 'program' => $program];
        if ($aff) {
            $out['affiliate'] = [
                'id' => $aff['id'],
                'code' => $aff['code'],
                'status' => $aff['status'],
                'payout_method' => $aff['payout_method'],
                'payout_details' => $aff['payout_details'],
                'created_at' => $aff['created_at'],
                'commission_type' => $aff['commission_type'] ?: $program['commission_type'],
                'commission_value' => $aff['commission_type'] ? (float) $aff['commission_value'] : $program['commission_value'],
            ];
            $out['link'] = $service->getSystemUrl() . '/affiliate?ref=' . $aff['code'];
            $out['link_alt'] = $service->getSystemUrl() . '/a/' . $aff['code'];
            $out['balance'] = $service->getBalance((int) $aff['id']);
            $out['stats'] = $service->getAffiliateStats((int) $aff['id']);
        }

        return $out;
    }

    public function join(array $data): array
    {
        $accepted = !empty($data['accept_terms']) && $data['accept_terms'] !== '0';

        return $this->getService()->joinProgram((int) $this->getIdentity()->id, $accepted);
    }

    public function payout_settings_update(array $data): bool
    {
        $aff = $this->affiliate();
        if (empty($data['payout_method'])) {
            throw new InformationException('Please choose a payout method.');
        }

        return $this->getService()->updatePayoutSettings((int) $aff['id'], (string) $data['payout_method'], (string) ($data['payout_details'] ?? ''));
    }

    public function referral_get_list(array $data): array
    {
        $aff = $this->affiliate();

        return $this->getService()->getClientReferralList((int) $aff['id'], $data);
    }

    public function commission_get_list(array $data): array
    {
        $aff = $this->affiliate();
        $res = $this->getService()->getCommissionList(array_merge($data, ['affiliate_id' => $aff['id']]));
        // never expose the referred customer's identity or e-mail
        foreach ($res['list'] as &$row) {
            unset($row['first_name'], $row['last_name'], $row['email'], $row['client_id'], $row['affiliate_code']);
        }
        unset($row);

        return $res;
    }

    public function payout_get_list(array $data): array
    {
        $aff = $this->affiliate();
        $res = $this->getService()->getPayoutList(array_merge($data, ['affiliate_id' => $aff['id']]));
        foreach ($res['list'] as &$row) {
            unset($row['first_name'], $row['last_name'], $row['email'], $row['affiliate_code']);
        }
        unset($row);

        return $res;
    }

    public function payout_request(array $data): array
    {
        $aff = $this->activeAffiliate();

        return $this->getService()->requestPayout((int) $aff['id']);
    }

    public function payout_cancel(array $data): bool
    {
        $aff = $this->affiliate();
        if (empty($data['id'])) {
            throw new InformationException('Payout ID is missing.');
        }

        return $this->getService()->cancelPayout((int) $data['id'], (int) $aff['id']);
    }
}
