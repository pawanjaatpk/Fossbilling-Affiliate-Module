<?php

/**
 * Affiliate module for FOSSBilling - administrator API.
 * Licensed under the Apache License, Version 2.0
 */

namespace Box\Mod\Affiliate\Api;

use FOSSBilling\Api\AbstractApi;

class Admin extends AbstractApi
{
    private function perm(string $permission): void
    {
        $this->di['mod_service']('Staff')->checkPermissionsAndThrowException('affiliate', $permission);
    }

    private function required(array $fields, array $data): void
    {
        $this->di['validator']->checkRequiredParamsForArray($fields, $data);
    }

    /** Program statistics for the admin dashboard. */
    public function get_stats(array $data): array
    {
        return $this->getService()->getStats();
    }

    /* ----- Affiliates ----- */

    public function get_list(array $data): array
    {
        return $this->getService()->getAffiliateList($data);
    }

    public function get(array $data): array
    {
        $this->required(['id' => 'Affiliate ID is missing'], $data);

        return $this->getService()->getAffiliateDetail((int) $data['id']);
    }

    public function create(array $data): array
    {
        $this->required(['client_id' => 'Client ID is missing'], $data);

        return $this->getService()->createAffiliate((int) $data['client_id'], $data['code'] ?? null);
    }

    public function update(array $data): bool
    {
        $this->required(['id' => 'Affiliate ID is missing'], $data);

        return $this->getService()->updateAffiliate((int) $data['id'], $data);
    }

    public function set_status(array $data): bool
    {
        $this->required(['id' => 'Affiliate ID is missing', 'status' => 'Status is missing'], $data);

        return $this->getService()->setAffiliateStatus((int) $data['id'], (string) $data['status']);
    }

    public function delete(array $data): bool
    {
        $this->required(['id' => 'Affiliate ID is missing'], $data);
        $this->perm('manage_payouts');

        return $this->getService()->deleteAffiliate((int) $data['id']);
    }

    /* ----- Referrals ----- */

    public function referral_get_list(array $data): array
    {
        return $this->getService()->getReferralList($data);
    }

    /** Manually attach a client to an affiliate. client_id, affiliate_id, [include_past=1], [force=1]. */
    public function referral_assign(array $data): int
    {
        $this->required(['client_id' => 'Client ID is missing', 'affiliate_id' => 'Affiliate ID is missing'], $data);
        $this->perm('manage_payouts');

        return $this->getService()->assignReferral(
            (int) $data['client_id'],
            (int) $data['affiliate_id'],
            !empty($data['include_past']) && $data['include_past'] !== '0',
            !empty($data['force']) && $data['force'] !== '0'
        );
    }

    /* ----- Tracking health / self-healing ----- */

    /** Attributes missed signups and creates missing commissions for paid invoices. [days=30] */
    public function sync(array $data): array
    {
        $this->perm('manage_settings');

        return $this->getService()->sync(max(1, min(365, (int) ($data['days'] ?? 30))));
    }

    public function diagnostics(array $data): array
    {
        return $this->getService()->getDiagnostics();
    }

    /** Registers the event hooks with FOSSBilling immediately (no need to wait for cron). */
    public function connect_hooks(array $data): bool
    {
        $this->perm('manage_settings');

        return $this->getService()->connectHooks();
    }

    /* ----- Commissions ----- */

    public function commission_get_list(array $data): array
    {
        return $this->getService()->getCommissionList($data);
    }

    public function commission_approve(array $data): bool
    {
        $this->required(['id' => 'Commission ID is missing'], $data);

        return $this->getService()->setCommissionStatus((int) $data['id'], 'approve');
    }

    public function commission_reject(array $data): bool
    {
        $this->required(['id' => 'Commission ID is missing'], $data);

        return $this->getService()->setCommissionStatus((int) $data['id'], 'reject');
    }

    /** Approve many pending commissions at once. ids = [1,2,3] */
    public function commission_batch_approve(array $data): bool
    {
        $this->required(['ids' => 'IDs are missing'], $data);
        foreach ((array) $data['ids'] as $id) {
            try {
                $this->getService()->setCommissionStatus((int) $id, 'approve');
            } catch (\FOSSBilling\InformationException $e) {
                // skip commissions that are not pending
            }
        }

        return true;
    }

    /** Manual adjustment. Use a negative amount to deduct. */
    public function commission_create(array $data): int
    {
        $this->required(['affiliate_id' => 'Affiliate ID is missing', 'amount' => 'Amount is missing'], $data);
        $this->perm('manage_payouts');

        return $this->getService()->createManualCommission(
            (int) $data['affiliate_id'],
            (float) $data['amount'],
            (string) ($data['description'] ?? ''),
            !isset($data['approved']) || (bool) $data['approved']
        );
    }

    /* ----- Payouts ----- */

    public function payout_get_list(array $data): array
    {
        return $this->getService()->getPayoutList($data);
    }

    public function payout_mark_paid(array $data): bool
    {
        $this->required(['id' => 'Payout ID is missing'], $data);
        $this->perm('manage_payouts');

        return $this->getService()->markPayoutPaid((int) $data['id'], (string) ($data['transaction_ref'] ?? ''), (string) ($data['admin_note'] ?? ''));
    }

    public function payout_reject(array $data): bool
    {
        $this->required(['id' => 'Payout ID is missing'], $data);
        $this->perm('manage_payouts');

        return $this->getService()->rejectPayout((int) $data['id'], (string) ($data['admin_note'] ?? ''));
    }

    /** Creates a payout from the affiliate's available balance on their behalf. */
    public function payout_create(array $data): array
    {
        $this->required(['affiliate_id' => 'Affiliate ID is missing'], $data);
        $this->perm('manage_payouts');

        return $this->getService()->requestPayout((int) $data['affiliate_id']);
    }

    /* ----- Product commission overrides ----- */

    public function product_rate_get_list(array $data): array
    {
        return $this->getService()->getProductRates();
    }

    public function product_rate_set(array $data): bool
    {
        $this->required(['product_id' => 'Product is missing', 'rate_type' => 'Rate type is missing', 'rate_value' => 'Rate value is missing'], $data);
        $this->perm('manage_settings');

        return $this->getService()->setProductRate((int) $data['product_id'], (string) $data['rate_type'], (float) $data['rate_value']);
    }

    public function product_rate_delete(array $data): bool
    {
        $this->required(['product_id' => 'Product is missing'], $data);
        $this->perm('manage_settings');

        return $this->getService()->deleteProductRate((int) $data['product_id']);
    }

    /* ----- Settings ----- */

    public function settings_get(array $data): array
    {
        return $this->getService()->getSettings();
    }

    public function settings_update(array $data): bool
    {
        $this->perm('manage_settings');

        return $this->getService()->updateSettings($data);
    }
}
